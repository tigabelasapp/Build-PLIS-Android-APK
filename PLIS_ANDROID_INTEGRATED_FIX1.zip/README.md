# PLIS — Penggilas Laundry Information System

Aplikasi web responsif untuk operasional laundry: dashboard, transaksi, pelanggan, pelacakan proses per item, pembayaran, pengeluaran, laporan, master layanan, pengaturan, dan nota thermal.

## Status saat ini
- UI/fitur prototipe dipertahankan sebagai acuan desain.
- Data operasional masih disimpan di `localStorage` browser; belum sinkron antarperangkat.
- Panel Masuk Google tersedia di **Menu Tambahan PLIS**. Autentikasi memerlukan konfigurasi Firebase; login Google tidak otomatis mengaktifkan penyimpanan cloud.
- Integrasi Firestore, aturan keamanan cloud, dan migrasi data belum diterapkan.

## Mulai lokal
Prasyarat: Node.js versi yang mendukung Vite 8.

```bash
npm install
npm run dev
```

Buka alamat lokal yang ditampilkan Vite (konfigurasi default proyek menggunakan port 3000).

## Google Sign-In (opsional pada iterasi ini)
1. Buat/siapkan aplikasi web pada Firebase Console.
2. Aktifkan provider **Google** di Authentication.
3. Tambahkan domain lokal dan domain hosting yang sah pada Authorized domains.
4. Salin `.env.example` menjadi `.env.local`, lalu isi `VITE_FIREBASE_API_KEY`, `VITE_FIREBASE_AUTH_DOMAIN`, `VITE_FIREBASE_PROJECT_ID`, dan `VITE_FIREBASE_APP_ID`.
5. Jalankan ulang server dev.

Variabel `VITE_*` digunakan pada browser; jangan memasukkan service-account key atau rahasia server ke variabel frontend. Jika konfigurasi belum tersedia, tombol akan menjelaskan langkah yang diperlukan.

## Perintah

```bash
npm run dev    # server pengembangan
npm run lint   # pemeriksaan TypeScript
npm run build  # build produksi
npm run preview
```

## Dokumentasi untuk AI coding
Mulai dari [`AI_CONTEXT.md`](./AI_CONTEXT.md), lanjutkan ke [`docs/IMPLEMENTATION_PLAN.md`](./docs/IMPLEMENTATION_PLAN.md), lalu baca dokumen pada `docs/` sesuai kebutuhan. Model data, aliran data, dan aturan bisnis harus diperiksa sebelum mengubah transaksi atau penyimpanan.

## Struktur kode yang ada
```text
src/
├── App.tsx
├── main.tsx
├── components/
│   ├── layout/
│   ├── modals/
│   └── views/
├── context/LaundryContext.tsx
├── data/initialData.ts
├── hooks/
├── infrastructure/
│   ├── integrations/firebase-auth.ts
│   └── storage/local-storage.repository.ts
├── services/storage.service.ts
├── shared/constants/domain.ts
├── types/index.ts
└── utils/
```

Struktur `src/modules/` merupakan arah refactor bertahap; kode prototipe belum dipindahkan massal agar risiko perubahan perilaku tetap rendah.

## Build APK Android

Repositori ini menyediakan GitHub Actions untuk membangun APK debug secara otomatis.
Setelah kode diunggah ke GitHub, buka tab **Actions**, pilih **Build PLIS Android APK**, lalu unduh artefak **PLIS-Android-debug-APK** dari proses yang berhasil.

APK debug ditujukan untuk pengujian prototipe. Firebase Authentication dan sinkronisasi Firestore belum dianggap aktif hanya dengan membangun APK.
