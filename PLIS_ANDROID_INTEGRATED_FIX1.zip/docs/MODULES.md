# Daftar Modul PLIS

| Modul | Lokasi saat ini | Tanggung jawab | Data utama |
|---|---|---|---|
| Dashboard | `src/components/views/DashboardView.tsx` | Ringkasan operasional dan angka usaha | Transaksi, pembayaran, pengeluaran |
| Transaksi | `src/components/views/TransactionsView.tsx`, `src/components/modals/NewTransactionModal.tsx`, `TransactionDetailModal.tsx` | Membuat dan melihat transaksi serta item layanan | Transaksi, item transaksi |
| Pelanggan | `src/components/views/CustomersView.tsx` | Daftar dan informasi pelanggan | Pelanggan |
| Operasional | `src/components/views/ProcessTrackingView.tsx` | Melacak status tiap item laundry | Item transaksi |
| Pembayaran | `src/components/views/PaymentsView.tsx` | Catatan pembayaran dan status pelunasan | Pembayaran, transaksi |
| Pengeluaran | `src/components/views/ExpensesView.tsx` | Pencatatan biaya operasional | Pengeluaran |
| Laporan | `src/components/views/ReportsView.tsx` | Ringkasan laporan dari data transaksi dan keuangan | Transaksi, pembayaran, pengeluaran |
| Master Data | `src/components/views/MasterDataView.tsx` | Pengelolaan layanan dan tarif | Master layanan |
| Nota | `src/components/modals/ThermalReceiptModal.tsx` | Tampilan/cetak nota thermal | Snapshot transaksi tersimpan, pengaturan usaha |
| Pengaturan | `src/components/views/SettingsView.tsx` | Profil outlet, backup/impor data, pengaturan nota | Pengaturan dan seluruh data untuk ekspor |
| State & penyimpanan lokal | `src/context/LaundryContext.tsx` | State, operasi CRUD, ID, persistensi browser | Semua entitas saat ini |
| Akun | `src/infrastructure/integrations/firebase-auth.ts`, `src/components/layout/MobileDrawer.tsx` | Google Sign-In dan status akun | Identitas Firebase Auth; tidak menyimpan data bisnis ke cloud |

## Kontrak README modul
Untuk modul baru/yang sudah dipisah, gunakan bagian tetap: Tujuan; Data yang dimiliki; Fungsi publik; Bergantung pada; Dipakai oleh; Aturan bisnis; Pengujian; Batasan yang diketahui.


Template README modul: `docs/MODULE_README_TEMPLATE.md`. Folder `src/modules/` disiapkan sebagai target refactor; jangan menduplikasi fitur di sana sebelum migrasi kode dilakukan.
