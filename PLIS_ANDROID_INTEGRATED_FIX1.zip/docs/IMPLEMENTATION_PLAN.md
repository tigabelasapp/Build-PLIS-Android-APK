# PLIS — Implementation Plan Terintegrasi

> Dokumen ini menggabungkan rencana implementasi yang diberikan dengan peta struktur kode aktual pada iterasi ini. Rencana bisnis asli dipertahankan di bawah; catatan integrasi di bagian awal membedakan kondisi kode sekarang dari target, agar fitur yang baru direncanakan tidak dianggap sudah selesai.

## Status integrasi dengan kode saat ini

### Struktur aktual
- Entry point: `src/main.tsx` dan `src/App.tsx`.
- UI aktif: `src/components/layout/`, `src/components/views/`, dan `src/components/modals/`.
- State dan operasi data masih terpusat di `src/context/LaundryContext.tsx`.
- Persistensi lokal melalui `src/services/storage.service.ts` dan `src/infrastructure/storage/local-storage.repository.ts`.
- Entitas dan tipe ada di `src/types/index.ts`; konstanta domain ada di `src/shared/constants/domain.ts`.
- Folder `src/modules/` saat ini terutama berisi README domain; implementasi belum dipindahkan penuh ke dalam modul.

### Pemetaan rencana ke kode
| Area rencana | Lokasi kode utama | Status implementasi yang dapat dinyatakan dari struktur saat ini |
|---|---|---|
| Dashboard | `src/components/views/DashboardView.tsx` | UI tersedia; periksa kalkulasi terhadap data aktual saat pengujian. |
| Transaksi dan item | `src/components/views/TransactionsView.tsx`, `src/components/modals/NewTransactionModal.tsx`, `src/context/LaundryContext.tsx` | Alur UI dan state prototipe tersedia; aturan integritas harus diuji. |
| Detail nota/cetak | `src/components/modals/TransactionDetailModal.tsx`, `src/components/modals/ThermalReceiptModal.tsx` | Komponen tersedia; hasil cetak/perangkat perlu pengujian nyata. |
| Pelacakan pengerjaan | `src/components/views/ProcessTrackingView.tsx` | Tampilan tersedia; pastikan status per item tetap independen. |
| Pembayaran | `src/components/views/PaymentsView.tsx` | Tampilan tersedia; rekonsiliasi histori pembayaran dan `paidAmount` perlu diuji. |
| Pengeluaran | `src/components/views/ExpensesView.tsx` | Tampilan tersedia; keunikan ID dan konsistensi laporan perlu diuji. |
| Laporan | `src/components/views/ReportsView.tsx` | Tampilan tersedia; angka harus diverifikasi dari transaksi, pembayaran, dan pengeluaran. |
| Master data | `src/components/views/MasterDataView.tsx` | UI tersedia; perubahan master tidak boleh mengubah snapshot transaksi lama. |
| Pengaturan | `src/components/views/SettingsView.tsx` | UI tersedia; pengaturan struk/outlet perlu diuji. |
| Penyimpanan | `src/context/LaundryContext.tsx`, `src/services/storage.service.ts`, `src/infrastructure/storage/local-storage.repository.ts` | `localStorage`; belum menjadi sinkronisasi cloud lintas perangkat. |
| APK Android | `capacitor.config.ts`, `.github/workflows/build-android.yml` | Konfigurasi build tersedia; APK belum dianggap tervalidasi sebelum workflow berhasil. |

### Urutan kerja yang aman
1. **Baseline dan build** — pertahankan UI serta alur yang ada; jalankan install, pemeriksaan TypeScript, dan build produksi. Perbaiki error build sebelum refactor perilaku.
2. **Integritas data** — uji ID transaksi/pengeluaran yang permanen, snapshot harga/satuan, perhitungan total, termin pembayaran, dan status per item. Jangan mengubah skema secara spekulatif.
3. **Pemisahan lapisan** — pindahkan logika domain sedikit demi sedikit dari `LaundryContext.tsx` ke modul/service/repository yang jelas; jaga API UI dan hasil perilaku tetap sama.
4. **Pengujian operasional** — uji nota/cetak, WhatsApp, master data, laporan, backup/restore, dan data contoh.
5. **APK** — jalankan GitHub Actions dan baru nyatakan berhasil setelah artifact APK benar-benar terunggah.

### Aturan untuk implementer
- Dokumen ini adalah target dan peta kerja, bukan bukti bahwa semua fitur sudah selesai.
- Jangan mengubah fitur, model data, atau alur bisnis hanya untuk menyederhanakan refactor.
- ID yang sudah tersimpan harus tetap; edit data tidak membuat ID baru.
- Data transaksi menyimpan snapshot nama layanan, kategori, satuan, dan harga pada saat transaksi dibuat.
- Status pengerjaan per item terpisah dari status pembayaran.
- Data saat ini berada di `localStorage`; jangan mengklaim sinkronisasi antarperangkat atau keamanan cloud aktif.
- Perubahan struktur harus kecil, teruji, dan dokumentasinya diperbarui.

---

## Rencana implementasi sumber (dipertahankan)

# PLIS — Penggilas Laundry Information System

Aplikasi web operasional laundry modern terpadu yang memadukan alur transaksi kasir (POS), pelacakan status bertingkat independen per item cucian, pencatatan termin pembayaran (DP, sebagian, lunas), pembukuan pengeluaran usaha, serta pelaporan keuangan terperinci dengan cetak struk kasir thermal 58/80mm dan faktur digital WhatsApp/A4.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> Berdasarkan konfirmasi pada tahap klarifikasi:
> - **Identitas Sistem**: PLIS (Penggilas Laundry Information System) sebagai identitas resmi aplikasi dengan profil outlet default yang dapat disesuaikan di menu Pengaturan.
> - **Gaya Visual**: Modern Clean Slate & Emerald (slate gelap/terang berkelas dengan aksen emerald segar, tipografi tajam tabular untuk angka uang/bobot, tanpa ornamen berlebihan).
> - **Format Nota**: Terintegrasi ganda — mode struk thermal kasir (58mm/80mm siap print langsung dari browser) dan mode faktur/invoice digital lengkap (siap cetak PDF / salin format pesan WhatsApp dengan rincian status per item).

- **Confirmed Decision 1**: Status pengerjaan laundry dilacak **per item layanan** (bukan hanya global per nota), memungkinkan pelanggan mengambil item yang telah selesai lebih awal (misal: pakaian reguler selesai, sementara karpet/sepatu masih pengerjaan) tanpa merusak integritas nota.
- **Confirmed Decision 2**: Alur pembayaran terpisah secara fleksibel dari status pengerjaan (pesanan bisa dikerjakan/diambil dengan status Belum Dibayar, DP/Sebagian, atau Lunas sesuai kebijakan kasir).
- **Confirmed Decision 3**: Penyimpanan data menggunakan client-state reaktif dengan persistensi `localStorage` otomatis, dilengkapi fitur Backup/Restore JSON dan Reset Data Contoh agar sistem langsung siap pakai tanpa ketergantungan koneksi backend.

---

## 1. Overview & Core Concept

- **What It Does**: Memberikan platform operasional lengkap untuk pengusaha dan kasir laundry dalam mengelola 9 pilar bisnis:
  1. **Dashboard Eksekutif**: Metrik omzet harian/bulanan, item cucian aktif, antrean siap ambil, dan peringatan piutang pelanggan.
  2. **Transaksi Baru & Kasir POS**: Pembuatan nota penjualan cepat, pemilihan/pendaftaran pelanggan baru, input banyak item layanan dengan kuantitas, satuan master (kg, pcs, m²), harga otomatis, catatan khusus, dan estimasi waktu selesai.
  3. **Detail Nota & Cetak**: Tampilan faktur komprehensif, pelacak progres item, catatan pembayaran masuk, serta tombol cetak struk thermal kasir & share ke WhatsApp pelanggan.
  4. **Proses Laundry (Workflow Monitor)**: Papan pelacakan item cucian dengan 5 status bertahap:
     `Menunggu Pengerjaan` ➔ `Sedang Dikerjakan` ➔ `Selesai Dikerjakan` ➔ `Siap Diambil` ➔ `Diserahkan`.
  5. **Pembayaran & Kas**: Pengelolaan piutang, pencatatan termin pembayaran (tunai, transfer, QRIS), histori pembayaran, dan perhitungan otomatis sisa tagihan.
  6. **Pengeluaran Usaha**: Pencatatan biaya operasional (deterjen, parfum, listrik, gaji, perawatan mesin, sewa) dengan nomor nota unik permanen.
  7. **Laporan & Analisis**: Ringkasan performa finansial (arus kas masuk vs keluar, laba bersih, omzet per periode), analisis layanan terlaris, dan rekap beban usaha.
  8. **Master Data**: Manajemen layanan laundry, kategori (Kiloan, Satuan, Express, Dry Clean), satuan ukur (kg, pcs, set, meter), harga dasar, dan durasi pengerjaan standar.
  9. **Pengaturan Outlet**: Konfigurasi nama toko, alamat, nomor WhatsApp, catatan kaki struk, format penomoran nota otomatis (`INV/YYMM/XXXX`), dan alat cadangkan/pulihkan data.

- **Target Audience / Persona**: Pemilik laundry (owner), manajer operasional outlet, dan kasir harian yang membutuhkan sistem kerja cepat, akurat, informatif, dan tidak membingungkan.
- **Key Value**: Mengeliminasi kekeliruan pencucian antar item dalam satu nota, mencegah piutang tak tertagih, dan memberikan transparansi arus kas secara instan.

---

## 2. User Experience & Visual Design

### Key User Flows
1. **Penerimaan Cucian Baru (POS Flow)**:
   - Kasir membuka menu **Transaksi** ➔ klik **+ Transaksi Baru**.
   - Cari pelanggan lama via autocomplete atau klik cepat **+ Pelanggan Baru** (isi nama, telepon, alamat ringkas).
   - Tambah item layanan: pilih layanan dari Master Data (misal: "Cuci Komplit Reguler"), isi jumlah (misal: 4.5 kg), sistem otomatis mengisi tarif dan menghitung subtotal serta estimasi selesai.
   - Tambah item kedua (misal: "Sepatu Deep Clean", 1 pasang, estimasi 3 hari).
   - Tentukan nomor nota (otomatis sesuai pola atau manual).
   - Opsi pembayaran awal: Belum Bayar, Uang Muka (DP), atau Bayar Lunas (pilih metode: Tunai, Transfer Bank, QRIS).
   - Klik **Simpan & Terbitkan Nota** ➔ muncul dialog pratinjau Struk Thermal & Teks WhatsApp instan.

2. **Pengerjaan & Penyerahan Bertahap (Production Flow)**:
   - Petugas bagian cuci membuka menu **Proses Laundry**.
   - Terdapat tab filter status pengerjaan atau papan alur kerja.
   - Pakaian reguler selesai lebih cepat ➔ petugas mengubah status item pakaian reguler menjadi `Selesai Dikerjakan` lalu `Siap Diambil`.
   - Pelanggan datang mengambil pakaian reguler ➔ kasir klik `Serahkan` pada item tersebut. Transaksi utama tetap berstatus aktif karena item sepatu masih `Sedang Dikerjakan`.
   - Ketika sepatu selesai dan diserahkan, seluruh item dalam nota otomatis terpenuhi dan transaksi dinyatakan selesai.

3. **Pelunasan & Pengeluaran (Financial Flow)**:
   - Pelanggan dengan sisa tagihan melunasi pembayaran saat pengambilan ➔ kasir klik **Catat Pembayaran** di Detail Nota atau menu Pembayaran, isi nominal, sistem mengupdate sisa tagihan menjadi Rp 0.
   - Pengeluaran operasional (beli deterjen) dicatat di menu **Pengeluaran** dengan kategori dan nomor nota pengeluaran unik ➔ langsung terakumulasi pada Laporan Laba Rugi.

### Visual Identity & Theme
- **Aesthetic Direction**: Neo-Fintech Clean Slate & Emerald. Tampilan instrumen modern dengan struktur hierarki tegas, tanpa kartu menumpuk berlebih, dan tanpa elemen dekoratif buatan.
- **Color Palette**:
  - Background Utama: Slate Neutral Canvas (`bg-slate-50` / `bg-slate-900`)
  - Permukaan Kartu & Panel: Pure White (`bg-white` / `bg-slate-800/90`) dengan garis tepi halus (`border-slate-200` / `border-slate-700/60`).
  - Warna Aksen Utama: Emerald Precision (`bg-emerald-600`, `text-emerald-600`, `hover:bg-emerald-700`).
  - Warna Status Fungsional:
    - *Menunggu*: Amber Slate (`bg-amber-50 text-amber-800 border-amber-200`)
    - *Sedang Dikerjakan*: Blue Ocean (`bg-sky-50 text-sky-800 border-sky-200`)
    - *Selesai Dikerjakan*: Indigo Modern (`bg-indigo-50 text-indigo-800 border-indigo-200`)
    - *Siap Diambil*: Emerald Glow (`bg-emerald-50 text-emerald-800 border-emerald-200`)
    - *Diserahkan*: Slate Muted (`bg-slate-100 text-slate-600 border-slate-200`)
- **Typography**:
  - Display & Headings: `Plus Jakarta Sans` / modern geometric sans.
  - Angka Uang, Bobot, & Waktu: `tabular-nums` atau `font-mono` untuk presisi nilai rupiah dan kuantitas.
- **Anti-Slop Discipline**:
  - Tidak ada pill-badge tumpuk atau pulsing green dots tanpa alasan.
  - Teks metadata menggunakan pemisah tipografis (`·` atau `/`).
  - Label aksi menggunakan kata kerja lugas: *"Simpan Transaksi"*, *"Cetak Struk"*, *"Catat Bayar"*, *"Filter"*.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Item-Level Status vs Order-Level Status**
  - *Chosen Approach*: Setiap item cucian menyimpan statusnya sendiri (`statusPengerjaan: 'menunggu' | 'proses' | 'selesai' | 'siap_diambil' | 'diserahkan'`). Nota memiliki status turunan terhitung (`semua_diserahkan`, `sebagian_diserahkan`, `sedang_proses`, `antre`).
  - *Why*: Memenuhi kebutuhan nyata operasional laundry di mana pelanggan sering membawa cucian beragam jenis (cuci kilat vs sepatu/bedcover) dan ingin mengambil barang yang sudah selesai terlebih dahulu.
  - *Alternatives Considered*: Status nota global tunggal — ditolak karena membuat kasir kesulitan mencatat barang yang diambil terpisah.

- **Decision 2: Penomoran ID Unik & Permanen**
  - *Chosen Approach*: Generator ID sistematis berbasis timestamp dan sekuens (misal: `TRX-261015-001`, `EXP-261015-001`) dengan opsi penyesuaian manual oleh Owner saat input nota. Sebelum disimpan, ada validasi keunikan ID. Sekali disimpan, ID bersifat permanen dan tidak berubah saat tanggal/nama diedit.
  - *Why*: Menjamin akuntabilitas audit dan kepastian referensi saat dicetak pada struk fisik.

- **Decision 3: Local Storage First dengan Skema Terstruktur**
  - *Chosen Approach*: Seluruh data (Transaksi, Pelanggan, Layanan Master, Pengeluaran, Riwayat Pembayaran, Pengaturan) disimpan dalam state terpusat dengan auto-sync ke `localStorage` dan tombol Export/Import JSON.
  - *Why*: Sangat cepat (zero latency), tahan gangguan jaringan internet di area kasir, dan tidak memerlukan setup server tambahan yang berbelit.

---

## 4. Technical Architecture & Data Strategy

```
┌────────────────────────────────────────────────────────────────────────┐
│                   PLIS App Architecture (React 19)                    │
├────────────────────────────────────────────────────────────────────────┤
│  Top Navigation & Outlet Banner                                        │
│  [PLIS Logo] · [Outlet: Penggilas Laundry Utama] · [Jam Operasional]  │
├───────────────┬────────────────────────────────────────────────────────┤
│  Navigation   │  Active Workspace View                                 │
│  Sidebar      │                                                        │
│  ───────────  │  ┌──────────────────────────────────────────────────┐  │
│  1. Dashboard │  │ 1. Dashboard: KPI, Tren Omzet, Item Monitor      │  │
│  2. Transaksi │  │ 2. Transaksi POS: Form Nota, Keranjang Layanan   │  │
│  3. Pelanggan │  │ 3. Detail Transaksi: Rincian Nota & Tracking     │  │
│  4. Pengerjaan│  │ 4. Monitoring Pengerjaan: Kanban / List Item     │  │
│  5. Pembayaran│  │ 5. Pembayaran: Kas Masuk, Termin, Piutang        │  │
│  6. Pengeluara│  │ 6. Pengeluaran: Catat Biaya, Kategori, Nota Keluar│  │
│  7. Laporan   │  │ 7. Laporan: Arus Kas, Neraca Ringkas, Rekap      │  │
│  8. Master    │  │ 8. Master Data: Tarif, Satuan, Estimasi Waktu    │  │
│  9. Pengaturan│  │ 9. Pengaturan: Profil Usaha, Format Struk, Backup│  │
│               │  └──────────────────────────────────────────────────┘  │
├───────────────┴────────────────────────────────────────────────────────┤
│  Modals & Overlays (Thermal Receipt Preview, Invoice WhatsApp, Form)   │
├────────────────────────────────────────────────────────────────────────┤
│  Central Data Store (React Hooks + localStorage Persistence Engine)    │
│  - Transactions Store (Order + OrderItems)                             │
│  - Customers Store (CRM & Contact Info)                                │
│  - Services Store (Catalog & Pricing Rules)                            │
│  - Payments Store (Ledger & Partial Settlements)                       │
│  - Expenses Store (Disbursements & Vouchers)                           │
│  - Settings Store (Store Profile & Receipt Configurations)             │
└────────────────────────────────────────────────────────────────────────┘
```

### Data Models & Entity Relationships
- **Customer**: `id`, `name`, `phone`, `address`, `notes`, `createdAt`
- **ServiceMaster**: `id`, `name`, `category` (Kiloan, Satuan, Express, Sepatu, Dry Clean), `unit` (kg, pcs, m², pasang), `pricePerUnit`, `defaultDurationHours`, `description`
- **OrderItem**:
  - `id`: string unik
  - `serviceId`: string
  - `serviceName`: string
  - `quantity`: number
  - `unit`: string
  - `pricePerUnit`: number
  - `subtotal`: number
  - `estimatedCompletionDate`: ISO string
  - `status`: `'menunggu'` | `'proses'` | `'selesai'` | `'siap_diambil'` | `'diserahkan'`
  - `notes`: string (misal: "baju putih dipisah", "noda minyak di kerah")
  - `completedAt`?: ISO string
  - `deliveredAt`?: ISO string
- **Transaction**:
  - `id`: string unik (misal: `PLIS-2610-001`)
  - `customerId`: string
  - `customerName`: string
  - `customerPhone`: string
  - `createdAt`: ISO string
  - `items`: `OrderItem[]`
  - `totalAmount`: number
  - `discount`: number
  - `grandTotal`: number
  - `paidAmount`: number
  - `paymentStatus`: `'belum_bayar'` | `'sebagian'` | `'lunas'`
  - `notes`: string
- **PaymentRecord**:
  - `id`: string
  - `transactionId`: string
  - `amount`: number
  - `method`: `'tunai'` | `'transfer'` | `'qris'`
  - `date`: ISO string
  - `notes`: string
- **Expense**:
  - `id`: string (misal: `EXP-2610-001`)
  - `date`: ISO string
  - `category`: `'Bahan Baku (Sabun/Parfum)'` | `'Operasional & Listrik'` | `'Gaji Karyawan'` | `'Perawatan Alat'` | `'Sewa & Tempat'` | `'Lain-lain'`
  - `description`: string
  - `amount`: number
  - `recipient`: string
- **AppSettings**:
  - `storeName`: "PLIS — Penggilas Laundry Information System"
  - `storeAddress`: string
  - `storePhone`: string
  - `receiptFooter`: string
  - `taxPercentage`: number
  - `currencySymbol`: "Rp"
  - `thermalWidth`: "58mm" | "80mm"
