# Model Data PLIS

Dokumen ini merangkum model yang terdeteksi dari `src/types/index.ts`. Nama field dan tipe di bawah mengikuti kode prototipe; validasi bisnis dan constraint database belum semuanya ditegakkan oleh database karena penyimpanan saat ini lokal.

## Entitas dan pemilik

### Pelanggan (`Customer`)
- **Pemilik:** Master Data / Pelanggan.
- **Field:** `id: string` (ID), `name: string`, `phone: string`, `address: string`, `notes?: string`, `createdAt: string` (tanggal ISO).
- **Relasi:** satu pelanggan dapat terkait dengan banyak `Transaction` melalui `Transaction.customerId`.
- **Catatan:** transaksi juga menyimpan snapshot `customerName`, `customerPhone`, dan `customerAddress` opsional agar nota historis tidak bergantung sepenuhnya pada profil pelanggan yang dapat berubah.

### Layanan (`ServiceMaster`)
- **Pemilik:** Master Data / Layanan.
- **Field:** `id: string`, `name: string`, `category: ServiceCategory`, `unit: ServiceUnit`, `pricePerUnit: number`, `defaultDurationHours: number`, `description?: string`.
- **Relasi:** `OrderItem.serviceId` merujuk ke layanan.
- **Catatan:** harga dan satuan pada item transaksi harus disimpan sebagai snapshot. Perubahan master tidak boleh mengubah transaksi historis.

### Item Transaksi (`OrderItem`)
- **Pemilik:** Transaksi; status operasional dikelola Operasional.
- **Field:** `id: string`, `serviceId: string`, `serviceName: string`, `category: ServiceCategory`, `quantity: number`, `unit: ServiceUnit`, `pricePerUnit: number`, `subtotal: number`, `estimatedCompletionDate: string`, `status: ItemStatus`, `notes?: string`, `completedAt?: string`, `deliveredAt?: string`.
- **Relasi:** item tertanam dalam array `Transaction.items`; `serviceId` merujuk ke `ServiceMaster.id`.
- **Catatan:** `serviceName`, `category`, `unit`, dan `pricePerUnit` adalah snapshot pada waktu transaksi.

### Transaksi (`Transaction`)
- **Pemilik:** Transaksi.
- **Field:** `id: string` (ID unik permanen), `customerId: string`, `customerName: string`, `customerPhone: string`, `customerAddress?: string`, `createdAt: string`, `items: OrderItem[]`, `totalAmount: number`, `discount: number`, `grandTotal: number`, `paidAmount: number`, `paymentStatus: PaymentStatus`, `notes?: string`.
- **Relasi:** satu transaksi memiliki banyak item; satu transaksi dapat memiliki banyak `PaymentRecord` melalui `PaymentRecord.transactionId`.
- **Aturan:** jangan mengubah ID transaksi setelah tersimpan. Nilai total harus konsisten dengan item, diskon, dan pembayaran menurut aturan bisnis.

### Pembayaran (`PaymentRecord`)
- **Pemilik:** Keuangan / Pembayaran.
- **Field:** `id: string`, `transactionId: string`, `amount: number`, `method: PaymentMethod`, `date: string`, `notes?: string`, `customerName?: string`.
- **Relasi:** banyak pembayaran dapat terkait ke satu transaksi melalui `transactionId`.
- **Catatan:** jumlah pembayaran dan `Transaction.paidAmount` harus direkonsiliasi; hindari pembaruan parsial yang membuat keduanya berbeda.

### Pengeluaran (`Expense`)
- **Pemilik:** Keuangan / Pengeluaran.
- **Field:** `id: string` (ID unik permanen), `date: string`, `category: ExpenseCategory`, `description: string`, `amount: number`, `recipient: string`, `notes?: string`.
- **Relasi:** tidak memiliki relasi entitas wajib dalam model sekarang.

### Pengaturan (`AppSettings`)
- **Pemilik:** Pengaturan.
- **Field:** `storeName`, `storeTagline`, `storeAddress`, `storePhone`, `storeInstagram?`, `receiptFooter`, `currencySymbol`, `thermalWidth: '58mm' | '80mm'`, `idPrefix`, `expensePrefix`.
- **Relasi:** dipakai oleh layout, generator ID, dan nota.

## Enum / nilai terbatas
- `ItemStatus`: `menunggu`, `proses`, `selesai`, `siap_diambil`, `diserahkan`.
- `PaymentStatus`: `belum_bayar`, `sebagian`, `lunas`.
- `PaymentMethod`: `tunai`, `transfer`, `qris`.
- `ServiceUnit`: `kg`, `pcs`, `pasang`, `set`, `m²`, `meter`.
- `ServiceCategory`: `Kiloan`, `Satuan`, `Express`, `Sepatu & Tas`, `Dry Clean`, `Karpet & Gorden`, `Lainnya`.
- `ExpenseCategory`: kategori pengeluaran yang didefinisikan pada `src/types/index.ts`.

## Penyimpanan saat ini
`LaundryContext.tsx` menyimpan `settings`, `services`, `customers`, `transactions`, `payments`, dan `expenses` pada `localStorage` dengan key `plis_*_v1`. Belum ada database online untuk entitas bisnis.

## Target model online (belum diterapkan)
Sebelum Firestore diaktifkan, tentukan skema koleksi/dokumen, otorisasi per peran, aturan ID unik lintas perangkat, transaksi atomik untuk pembayaran, serta migrasi dan rekonsiliasi data lokal. Jangan menafsirkan tabel di atas sebagai aturan keamanan database yang sudah aktif.
