# [Nama Modul]

> Status: [belum dimigrasikan / sedang dimigrasikan / aktif]

## Tujuan
Jelaskan tanggung jawab modul dalam 1–3 kalimat.

## Data yang dimiliki
- Entitas/field yang menjadi tanggung jawab modul.
- Data historis atau snapshot yang tidak boleh diubah.

## Fungsi publik
Daftar API yang diekspor dari `index.ts`. Jangan mencantumkan fungsi internal sebagai API publik.

## Bergantung pada
Daftar modul/API publik yang dipakai dan infrastruktur yang dibutuhkan.

## Dipakai oleh
Daftar modul yang menggunakan API publik modul ini.

## Aturan bisnis
Aturan yang harus tetap benar, termasuk ID, relasi, dan integritas data.

## Pengujian
Daftar tes unit, integrasi, dan alur UI yang harus lulus.

## Batasan yang diketahui
Fitur yang belum ada, risiko, atau migrasi yang masih berjalan.
