# Konvensi Penamaan

- Istilah domain dan label UI menggunakan Bahasa Indonesia yang konsisten: `pelanggan`, `layanan`, `transaksi`, `pembayaran`, `pengeluaran`, `nota`, `status`.
- Istilah teknis mengikuti konvensi ekosistem: `component`, `service`, `repository`, `infrastructure`, `hook`, `type`, `event`.
- React component: PascalCase, contoh `MobileDrawer.tsx`.
- Function/variable: camelCase, contoh `addTransaction`.
- Type/interface: PascalCase, contoh `PaymentRecord`.
- Konstanta global: UPPER_SNAKE_CASE bila sesuai, contoh `ORDER_STATUS`.
- File yang sudah ada tidak perlu diganti nama sekaligus; perubahan nama harus memperbarui semua import dan dokumentasi.
- Modul baru menggunakan satu pintu publik `index.ts`; file internal tidak diimpor langsung oleh modul lain.
