# Glosarium PLIS

| Istilah | Makna |
|---|---|
| Pelanggan | Orang yang menggunakan jasa laundry |
| Layanan | Jenis jasa laundry yang ditawarkan beserta tarif dan satuannya |
| Master Data | Data referensi yang digunakan saat membuat transaksi |
| Transaksi | Catatan penerimaan cucian milik pelanggan |
| Item transaksi | Satu jenis layanan/baris pekerjaan di dalam transaksi |
| Pembayaran | Catatan uang yang dibayarkan untuk suatu transaksi |
| Piutang | Sisa kewajiban pelanggan yang belum dibayar; konsep ini belum menjadi entitas terpisah pada tipe saat ini |
| Pengeluaran | Biaya yang dicatat oleh usaha |
| Nota | Bukti transaksi yang ditampilkan atau dicetak |
| Snapshot | Salinan nilai pada saat transaksi dibuat agar histori tidak berubah saat master berubah |
| Repository | Lapisan akses data yang memisahkan kode bisnis dari teknologi penyimpanan |
| Infrastructure | Implementasi teknis seperti database, penyimpanan, atau integrasi eksternal |
| Google Sign-In | Autentikasi identitas menggunakan akun Google melalui Firebase Authentication |
| Sinkronisasi | Penyamaan data lintas perangkat melalui penyimpanan bersama; belum aktif pada iterasi ini |
