# Peta Proyek PLIS

## Entry point
- `index.html`: HTML shell dan metadata.
- `src/main.tsx`: memasang React dan CSS global.
- `src/App.tsx`: provider state, layout, navigasi tampilan, dan modal global.
- `src/index.css`: gaya global.

## Peta kode aktif saat ini
- `src/components/layout/`: navbar, sidebar, navigasi bawah, dan drawer Menu Tambahan.
- `src/components/views/`: dashboard, transaksi, pelanggan, proses laundry, pembayaran, pengeluaran, laporan, master data, dan pengaturan.
- `src/components/modals/`: modal transaksi baru, detail transaksi, dan nota thermal.
- `src/context/LaundryContext.tsx`: state aplikasi, operasi CRUD, dan generator ID.
- `src/services/storage.service.ts`: pintu service untuk baca/simpan data persisten.
- `src/infrastructure/storage/local-storage.repository.ts`: adapter `localStorage` dengan penanganan error.
- `src/types/index.ts`: tipe entitas, status, tab, dan unit.
- `src/data/initialData.ts`: data awal/demo.
- `src/utils/`: formatter dan ekspor CSV.
- `src/hooks/`: hook PWA.
- `src/infrastructure/integrations/firebase-auth.ts`: helper Firebase Authentication untuk Google Sign-In.
- `src/shared/constants/domain.ts`: konstanta status, metode pembayaran, satuan, dan lebar nota.
- `docs/`: dokumentasi arsitektur, model data, aliran data, aturan bisnis, serta rencana implementasi yang dipetakan ke kode aktual.

## Peta target refactor
`src/modules/` memuat README dokumentasi per domain: `dashboard`, `master-data`, `transaksi`, `nota`, `operasional`, `keuangan`, dan `akun`. Implementasi fitur belum dipindahkan ke folder tersebut. Gunakan `docs/IMPLEMENTATION_PLAN.md` untuk urutan kerja dan pemetaan target ke kode aktual.

## Aliran data saat ini
Komponen → `useLaundry()` → `LaundryContext` → `storage.service` → `local-storage.repository` → `localStorage`. State dan CRUD domain masih berada di context; ini adalah langkah awal, bukan arsitektur final.

## Status online
Tombol Google Sign-In berada di `src/components/layout/MobileDrawer.tsx` pada **Menu Tambahan PLIS**. Firebase Authentication membutuhkan konfigurasi dan belum diverifikasi end-to-end. Data operasional belum memakai Firestore.
