# Changelog

## 2026-10-15 — Iterasi fondasi AI-friendly
- Menambahkan `AI_CONTEXT.md` sebagai titik masuk AI coding.
- Menambahkan peta proyek, daftar modul, model data, aliran data, aturan bisnis, konvensi nama, glosarium, arsitektur, dan rencana pengujian.
- Menambahkan kerangka integrasi Firebase Authentication untuk Google Sign-In.
- Menambahkan panel akun pada `Menu Tambahan PLIS`.
- Menegaskan bahwa data bisnis masih menggunakan `localStorage`; Firestore dan sinkronisasi online belum diterapkan.
- Mempertahankan struktur komponen prototipe saat ini untuk menghindari refactor besar yang belum diuji.

## 2026-10-15 — Iterasi 02: audit dan dokumentasi arsitektur
- Menambahkan `docs/AUDIT_REPORT.md` dengan temuan statis, risiko, status verifikasi, dan kriteria selesai.
- Menambahkan `docs/REFACTOR_PLAN.md` untuk peta migrasi dari lokasi kode aktual ke modul domain.
- Menstandarkan template README modul dan menambahkan README status untuk Dashboard, Master Data, Transaksi, Nota, Operasional, Keuangan, dan Akun.
- Menegaskan bahwa folder `src/modules/` saat ini merupakan scaffolding dokumentasi, bukan klaim bahwa implementasi telah dipindahkan.
- Build/lint belum dapat diverifikasi karena dependensi belum terpasang; `npm install` timeout dan `npm run lint` tidak menemukan type definitions Vite.

- Mengekstrak akses `localStorage` dari `LaundryContext.tsx` ke `storage.service.ts` dan `local-storage.repository.ts` tanpa mengubah key penyimpanan `plis_*_v1`; operasi baca/tulis menangani error agar storage bermasalah tidak langsung membuat aplikasi crash.
- Menghapus pemanggilan `localStorage.clear()` dari reset demo agar tidak menghapus data lain pada origin browser; state PLIS kembali ke data awal dan disimpan kembali lewat key PLIS.
