# Arsitektur dan Rencana Refactor

## Kondisi sekarang
Prototipe memakai React Context (`LaundryContext`) sebagai gabungan state, aturan CRUD, generator ID, dan penyimpanan `localStorage`. Ini mudah dijalankan untuk prototipe, tetapi membuat batas modul dan penggantian storage belum terisolasi.

## Target dependensi satu arah
`page/component → service → repository → infrastructure`.

- Page/component: tampilan dan interaksi pengguna.
- Service: validasi dan alur bisnis.
- Repository: kontrak baca/tulis data.
- Infrastructure: adapter `localStorage`, IndexedDB, atau API/cloud.
- Modul lain mengakses fungsi publik melalui `index.ts`, bukan file internal.

## Tahap refactor aman
1. Tambahkan dokumentasi dan model data (iterasi sekarang).
2. Pisahkan konstanta status/unit/metode pembayaran dari string yang tersebar.
3. Definisikan interface repository dan adapter localStorage tanpa mengubah perilaku UI.
4. Pindahkan operasi context ke service secara bertahap.
5. Pecah komponen ke modul domain dan publikasikan API melalui `index.ts`.
6. Implementasikan adapter cloud setelah model, autentikasi, otorisasi, dan migrasi disepakati.
7. Tegakkan batas import menggunakan lint/test.

Jangan memindahkan seluruh kode sekaligus; setiap tahap harus bisa dibangun dan diuji sebelum tahap berikutnya.
