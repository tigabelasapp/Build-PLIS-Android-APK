# Aliran Data PLIS

## Aliran saat ini
1. Tampilan React membaca state melalui `useLaundry()`.
2. `LaundryContext` mengelola state transaksi, pelanggan, layanan, pembayaran, pengeluaran, dan pengaturan.
3. `useEffect` memanggil `src/services/storage.service.ts`.
4. Service meneruskan operasi ke `src/infrastructure/storage/local-storage.repository.ts`, yang membaca/menulis `localStorage` dengan penanganan error.
5. Komponen laporan dan dashboard membaca data dari context.
6. Komponen nota membaca snapshot transaksi yang dipilih dan pengaturan outlet.
7. Ekspor/backup disusun melalui utilitas CSV dan fungsi ekspor JSON pada context.

## Aliran akun
1. `MobileDrawer` menampilkan status akun dan tombol Masuk Google.
2. `src/infrastructure/integrations/firebase-auth.ts` membaca konfigurasi Firebase dari environment.
3. Bila konfigurasi tersedia, Firebase Authentication membuka Google Sign-In popup.
4. Login hanya menetapkan identitas pengguna. Data operasional belum dipindahkan ke Firestore.

## Target arsitektur
`Page/Component → Service → Repository → Infrastructure`.
Komponen UI tidak boleh berkomunikasi langsung dengan database. Repository menjadi kontrak untuk membaca/menulis data; implementasi lokal dapat diganti dengan cloud setelah skema dan aturan keamanan siap. Ekstraksi storage yang ada merupakan langkah awal; CRUD domain belum sepenuhnya dipindahkan ke service/repository.

## Event antarmodul
Untuk proses lintas modul, event boleh digunakan setelah operasi utama berhasil tersimpan. Contoh konseptual: `transaction.created` dapat memicu pembuatan nota atau pembaruan piutang. Event handler harus idempoten, mencatat kegagalan, dan tidak membuat catatan ganda. Event sederhana di frontend bukan pengganti transaksi atomik di database untuk operasi keuangan.
