# Aturan Bisnis PLIS

## Data dan ID
- ID transaksi dan ID pengeluaran harus unik serta permanen setelah tersimpan.
- Edit data dilakukan pada objek dengan ID yang sama; jangan membuat identitas baru secara tidak sengaja.
- Untuk penyimpanan lokal, pemeriksaan unik hanya berlaku pada data di browser tersebut. Migrasi online perlu ID/counter yang aman terhadap penulisan bersamaan dari beberapa perangkat.

## Master dan snapshot transaksi
- Master Layanan adalah sumber harga, kategori, satuan, dan durasi default untuk transaksi baru.
- Transaksi menyimpan snapshot nama layanan, kategori, satuan, harga per unit, kuantitas, dan subtotal.
- Perubahan master tidak mengubah snapshot transaksi lama.

## Status operasional
- Status yang tersedia dalam tipe saat ini: `menunggu`, `proses`, `selesai`, `siap_diambil`, `diserahkan`.
- Perubahan status harus dilakukan pada item yang tepat, bukan mengubah item lain dalam transaksi secara tidak sengaja.
- Aturan transisi final perlu dipastikan dan dites sebelum penerapan produksi.

## Pembayaran dan pengeluaran
- Pembayaran harus memiliki `transactionId` yang valid dan nominal positif.
- `paidAmount`, jumlah catatan pembayaran, dan `paymentStatus` harus konsisten.
- Perhitungan sisa bayar tidak boleh menghasilkan nilai negatif tanpa aturan kredit/refund yang eksplisit.
- Pengeluaran memiliki ID unik permanen dan nominal yang tervalidasi.

## Nota
- Nota menampilkan snapshot transaksi yang sudah tersimpan; jangan mengambil harga terkini dari master untuk mengubah nilai nota historis.
- Data header dan footer nota berasal dari pengaturan usaha.

## Identitas dan keamanan
- Login Google bukan otomatis pemberian peran OWNER atau KARYAWAN.
- Sebelum online, otorisasi harus ditegakkan di backend/database, bukan hanya menyembunyikan tombol di UI.
- Jangan menaruh kredensial privat atau service-account key di kode frontend.
