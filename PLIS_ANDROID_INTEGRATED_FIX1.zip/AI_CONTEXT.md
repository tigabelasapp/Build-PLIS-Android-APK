# AI_CONTEXT.md — Panduan Kerja AI untuk PLIS

## Tujuan proyek
PLIS (Penggilas Laundry Information System) adalah aplikasi web responsif untuk operasional laundry. Desain dan alur yang sudah ada dalam prototipe merupakan acuan utama; jangan mengganti konsep visual atau menghapus fitur tanpa persetujuan.

## Stack yang terdeteksi
- React 19 + TypeScript
- Vite
- Tailwind CSS 4 melalui plugin Vite
- lucide-react untuk ikon
- Firebase Authentication (Google Sign-In) disiapkan sebagai integrasi opsional
- Penyimpanan data aplikasi saat ini masih `localStorage`, diakses melalui `src/services/storage.service.ts` dan `src/infrastructure/storage/local-storage.repository.ts`; state/CRUD domain masih dikelola `src/context/LaundryContext.tsx`

## Urutan dokumen yang dibaca
1. `AI_CONTEXT.md`
2. `README.md`
3. `docs/PROJECT_MAP.md`
4. `docs/MODULES.md`
5. `docs/DATA_MODEL.md`
6. `docs/DATA_FLOW.md`
7. `docs/BUSINESS_RULES.md`
8. `docs/NAMING_CONVENTIONS.md` dan `docs/GLOSSARY.md`
9. `docs/AUDIT_REPORT.md` dan `docs/REFACTOR_PLAN.md` sebelum memindahkan kode
10. README modul yang sedang dikerjakan, lalu kode dan tes terkait

## Aturan perubahan
- Pertahankan desain, menu, dan perilaku yang sudah ada kecuali perubahan diminta secara eksplisit.
- Jangan mengarang bahwa autentikasi atau sinkronisasi online sudah aktif. Google Sign-In hanya berfungsi setelah konfigurasi Firebase valid; data bisnis tetap lokal pada iterasi ini.
- Jangan menghapus atau menimpa data lokal pengguna. Sebelum migrasi cloud, rancang ekspor, migrasi, rekonsiliasi ID, penanganan duplikasi, dan jalur pemulihan.
- Jangan mengubah ID transaksi atau ID pengeluaran yang telah tersimpan.
- Harga/unit pada item transaksi adalah snapshot historis. Mengubah Master Layanan tidak boleh mengubah transaksi lama.
- Status dan istilah domain harus dipusatkan di `src/shared/constants/` dan tipe bersama; hindari string status tersebar.
- Perubahan harus disertai pembaruan dokumentasi dan pengujian yang relevan. Jangan menandai build/lint lulus jika perintahnya belum benar-benar berhasil.
- Jangan menganggap struktur folder sebagai pengganti otorisasi backend. Validasi hak akses dan aturan database harus ditegakkan pada server/database saat sinkronisasi cloud diterapkan.

## Arah arsitektur yang dituju
`page/component → service → repository → infrastructure`.
Modul lain sebaiknya mengakses API publik modul melalui `index.ts`, bukan mengimpor file internalnya. Terapkan bertahap agar refactor tidak merusak prototipe.

## Perintah proyek
- `npm run dev` — server pengembangan
- `npm run lint` — pemeriksaan TypeScript
- `npm run build` — build produksi

## Status implementasi saat dokumen ini dibuat
- UI dan fitur prototipe tetap berada pada struktur komponen yang sudah ada.
- Tombol Masuk Google telah ditambahkan di drawer Menu Tambahan.
- Integrasi Google Sign-In memerlukan variabel `VITE_FIREBASE_*` pada `.env.local` dan pengaturan Firebase Console.
- Transaksi, pelanggan, layanan, pembayaran, pengeluaran, dan pengaturan masih memakai `localStorage`; belum ada sinkronisasi Firestore.

## Status audit iterasi 02
- `docs/AUDIT_REPORT.md` mencatat temuan yang diperiksa statis serta keterbatasan verifikasi.
- `docs/REFACTOR_PLAN.md` adalah rencana migrasi dari kode aktif ke modul domain.
- `src/modules/*/README.md` saat ini hanya scaffolding dokumentasi; service, repository, dan API publik domain belum diterapkan menyeluruh. Akses penyimpanan lokal sudah diekstrak ke service/repository sebagai langkah awal.
- Pada lingkungan audit ini, `npm run lint` tidak dapat selesai karena type definitions Vite tidak tersedia; `npm install` mengalami timeout. Build produksi belum terverifikasi.


## Acuan implementasi
Sebelum mengubah fitur atau struktur, baca `docs/IMPLEMENTATION_PLAN.md`. Dokumen tersebut memisahkan kondisi kode saat ini dari target implementasi; jangan menganggap target sebagai fitur yang sudah teruji.
