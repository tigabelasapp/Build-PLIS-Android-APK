import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Transaction,
  Customer,
  ServiceMaster,
  PaymentRecord,
  Expense,
  AppSettings,
  MainTab,
  ItemStatus,
  PaymentMethod,
} from '../types';
import {
  INITIAL_SETTINGS,
  INITIAL_SERVICES,
  INITIAL_CUSTOMERS,
  INITIAL_TRANSACTIONS,
  INITIAL_PAYMENTS,
  INITIAL_EXPENSES,
} from '../data/initialData';
import { loadStoredValue, saveStoredValue } from '../services/storage.service';

interface LaundryContextType {
  // State
  activeTab: MainTab;
  setActiveTab: (tab: MainTab) => void;
  viewportMode: 'mobile' | 'desktop';
  setViewportMode: (mode: 'mobile' | 'desktop') => void;
  isMobileMenuOpen: boolean;
  setIsMobileMenuOpen: (open: boolean) => void;
  transactions: Transaction[];
  customers: Customer[];
  services: ServiceMaster[];
  payments: PaymentRecord[];
  expenses: Expense[];
  settings: AppSettings;
  selectedTransactionId: string | null;
  setSelectedTransactionId: (id: string | null) => void;
  receiptModalTransaction: Transaction | null;
  setReceiptModalTransaction: (tx: Transaction | null) => void;
  isNewTxModalOpen: boolean;
  setIsNewTxModalOpen: (open: boolean) => void;

  // ID Management & Uniqueness Check
  generateNextTransactionId: () => string;
  isTransactionIdAvailable: (id: string, excludeId?: string) => boolean;
  generateNextExpenseId: () => string;
  isExpenseIdAvailable: (id: string, excludeId?: string) => boolean;

  // Transactions
  addTransaction: (tx: Transaction, initialPayment?: { amount: number; method: PaymentMethod; notes?: string }) => { success: boolean; error?: string };
  updateTransaction: (tx: Transaction) => void;
  deleteTransaction: (id: string) => void;
  updateItemStatus: (txId: string, itemId: string, status: ItemStatus) => void;
  deliverItem: (txId: string, itemId: string) => void;

  // Payments
  addPayment: (txId: string, amount: number, method: PaymentMethod, notes?: string) => { success: boolean; error?: string };

  // Customers
  addCustomer: (data: Omit<Customer, 'id' | 'createdAt'>) => Customer;
  updateCustomer: (customer: Customer) => void;
  deleteCustomer: (id: string) => void;

  // Services Master Data
  addService: (data: Omit<ServiceMaster, 'id'>) => ServiceMaster;
  updateService: (service: ServiceMaster) => void;
  deleteService: (id: string) => void;

  // Expenses
  addExpense: (expense: Expense) => { success: boolean; error?: string };
  deleteExpense: (id: string) => void;

  // Settings & Storage
  updateSettings: (newSettings: Partial<AppSettings>) => void;
  resetToDemo: () => void;
  exportDataJSON: () => string;
  importDataJSON: (jsonStr: string) => { success: boolean; message: string };
}

const LaundryContext = createContext<LaundryContextType | undefined>(undefined);

const STORAGE_KEYS = {
  SETTINGS: 'plis_settings_v1',
  SERVICES: 'plis_services_v1',
  CUSTOMERS: 'plis_customers_v1',
  TRANSACTIONS: 'plis_transactions_v1',
  PAYMENTS: 'plis_payments_v1',
  EXPENSES: 'plis_expenses_v1',
};

export const LaundryProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activeTab, setActiveTab] = useState<MainTab>('dashboard');
  const [viewportMode, setViewportMode] = useState<'mobile' | 'desktop'>('mobile');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [selectedTransactionId, setSelectedTransactionId] = useState<string | null>(null);
  const [receiptModalTransaction, setReceiptModalTransaction] = useState<Transaction | null>(null);
  const [isNewTxModalOpen, setIsNewTxModalOpen] = useState(false);

  // Load from localStorage or seed
  const [settings, setSettings] = useState<AppSettings>(() => loadStoredValue(STORAGE_KEYS.SETTINGS, INITIAL_SETTINGS));

  const [services, setServices] = useState<ServiceMaster[]>(() => loadStoredValue(STORAGE_KEYS.SERVICES, INITIAL_SERVICES));

  const [customers, setCustomers] = useState<Customer[]>(() => loadStoredValue(STORAGE_KEYS.CUSTOMERS, INITIAL_CUSTOMERS));

  const [transactions, setTransactions] = useState<Transaction[]>(() => loadStoredValue(STORAGE_KEYS.TRANSACTIONS, INITIAL_TRANSACTIONS));

  const [payments, setPayments] = useState<PaymentRecord[]>(() => loadStoredValue(STORAGE_KEYS.PAYMENTS, INITIAL_PAYMENTS));

  const [expenses, setExpenses] = useState<Expense[]>(() => loadStoredValue(STORAGE_KEYS.EXPENSES, INITIAL_EXPENSES));

  // Sync state changes to localStorage
  useEffect(() => {
    saveStoredValue(STORAGE_KEYS.SETTINGS, settings);
  }, [settings]);

  useEffect(() => {
    saveStoredValue(STORAGE_KEYS.SERVICES, services);
  }, [services]);

  useEffect(() => {
    saveStoredValue(STORAGE_KEYS.CUSTOMERS, customers);
  }, [customers]);

  useEffect(() => {
    saveStoredValue(STORAGE_KEYS.TRANSACTIONS, transactions);
  }, [transactions]);

  useEffect(() => {
    saveStoredValue(STORAGE_KEYS.PAYMENTS, payments);
  }, [payments]);

  useEffect(() => {
    saveStoredValue(STORAGE_KEYS.EXPENSES, expenses);
  }, [expenses]);

  // ID generator & unique validator for Transactions
  const isTransactionIdAvailable = (id: string, excludeId?: string): boolean => {
    const clean = id.trim().toUpperCase();
    if (!clean) return false;
    return !transactions.some((t) => t.id.toUpperCase() === clean && t.id !== excludeId);
  };

  const generateNextTransactionId = (): string => {
    const now = new Date();
    const yy = String(now.getFullYear()).slice(-2);
    const mm = String(now.getMonth() + 1).padStart(2, '0');
    const prefix = `${settings.idPrefix || 'PLIS'}-${yy}${mm}`;

    // Find highest count matching prefix
    let maxNum = 0;
    transactions.forEach((t) => {
      if (t.id.startsWith(prefix)) {
        const parts = t.id.split('-');
        const lastPart = parts[parts.length - 1];
        const num = parseInt(lastPart, 10);
        if (!isNaN(num) && num > maxNum) {
          maxNum = num;
        }
      }
    });

    const nextNum = String(maxNum + 1).padStart(3, '0');
    return `${prefix}-${nextNum}`;
  };

  // ID generator & unique validator for Expenses
  const isExpenseIdAvailable = (id: string, excludeId?: string): boolean => {
    const clean = id.trim().toUpperCase();
    if (!clean) return false;
    return !expenses.some((e) => e.id.toUpperCase() === clean && e.id !== excludeId);
  };

  const generateNextExpenseId = (): string => {
    const now = new Date();
    const yy = String(now.getFullYear()).slice(-2);
    const mm = String(now.getMonth() + 1).padStart(2, '0');
    const prefix = `${settings.expensePrefix || 'EXP'}-${yy}${mm}`;

    let maxNum = 0;
    expenses.forEach((e) => {
      if (e.id.startsWith(prefix)) {
        const parts = e.id.split('-');
        const lastPart = parts[parts.length - 1];
        const num = parseInt(lastPart, 10);
        if (!isNaN(num) && num > maxNum) {
          maxNum = num;
        }
      }
    });

    const nextNum = String(maxNum + 1).padStart(3, '0');
    return `${prefix}-${nextNum}`;
  };

  // Transactions Management
  const addTransaction = (
    tx: Transaction,
    initialPayment?: { amount: number; method: PaymentMethod; notes?: string }
  ): { success: boolean; error?: string } => {
    const cleanId = tx.id.trim();
    if (!cleanId) {
      return { success: false, error: 'Nomor Nota tidak boleh kosong.' };
    }

    if (!isTransactionIdAvailable(cleanId)) {
      return { success: false, error: `Nomor Nota "${cleanId}" sudah pernah digunakan. Harap gunakan ID lain.` };
    }

    if (!tx.items || tx.items.length === 0) {
      return { success: false, error: 'Harap tambahkan minimal 1 item layanan cucian.' };
    }

    const newTx: Transaction = {
      ...tx,
      id: cleanId,
    };

    let newPayments = [...payments];

    // If an initial payment was entered
    if (initialPayment && initialPayment.amount > 0) {
      const payRecord: PaymentRecord = {
        id: `PAY-${Date.now()}`,
        transactionId: cleanId,
        amount: initialPayment.amount,
        method: initialPayment.method,
        date: new Date().toISOString(),
        notes: initialPayment.notes || 'Pembayaran awal saat nota dibuat',
        customerName: tx.customerName,
      };
      newPayments = [payRecord, ...newPayments];
      newTx.paidAmount = initialPayment.amount;

      if (newTx.paidAmount >= newTx.grandTotal) {
        newTx.paymentStatus = 'lunas';
      } else {
        newTx.paymentStatus = 'sebagian';
      }
    }

    setTransactions((prev) => [newTx, ...prev]);
    setPayments(newPayments);

    return { success: true };
  };

  const updateTransaction = (updatedTx: Transaction) => {
    setTransactions((prev) =>
      prev.map((t) => (t.id === updatedTx.id ? updatedTx : t))
    );
  };

  const deleteTransaction = (id: string) => {
    setTransactions((prev) => prev.filter((t) => t.id !== id));
    setPayments((prev) => prev.filter((p) => p.transactionId !== id));
    if (selectedTransactionId === id) setSelectedTransactionId(null);
    if (receiptModalTransaction?.id === id) setReceiptModalTransaction(null);
  };

  const updateItemStatus = (txId: string, itemId: string, status: ItemStatus) => {
    setTransactions((prev) =>
      prev.map((tx) => {
        if (tx.id !== txId) return tx;
        const now = new Date().toISOString();
        const updatedItems = tx.items.map((item) => {
          if (item.id !== itemId) return item;
          return {
            ...item,
            status,
            completedAt: status === 'selesai' || status === 'siap_diambil' || status === 'diserahkan' 
              ? (item.completedAt || now) 
              : undefined,
            deliveredAt: status === 'diserahkan' ? (item.deliveredAt || now) : undefined,
          };
        });
        return {
          ...tx,
          items: updatedItems,
        };
      })
    );
  };

  const deliverItem = (txId: string, itemId: string) => {
    updateItemStatus(txId, itemId, 'diserahkan');
  };

  // Payments Management
  const addPayment = (
    txId: string,
    amount: number,
    method: PaymentMethod,
    notes?: string
  ): { success: boolean; error?: string } => {
    if (amount <= 0) {
      return { success: false, error: 'Jumlah pembayaran harus lebih dari Rp 0.' };
    }

    const tx = transactions.find((t) => t.id === txId);
    if (!tx) {
      return { success: false, error: 'Transaksi tidak ditemukan.' };
    }

    const currentPaid = tx.paidAmount || 0;
    const newPaid = currentPaid + amount;
    const isLunas = newPaid >= tx.grandTotal;

    const newPaymentRecord: PaymentRecord = {
      id: `PAY-${Date.now()}`,
      transactionId: txId,
      amount,
      method,
      date: new Date().toISOString(),
      notes: notes || 'Pencatatan pembayaran di kasir',
      customerName: tx.customerName,
    };

    setPayments((prev) => [newPaymentRecord, ...prev]);

    setTransactions((prev) =>
      prev.map((t) => {
        if (t.id !== txId) return t;
        return {
          ...t,
          paidAmount: newPaid,
          paymentStatus: isLunas ? 'lunas' : 'sebagian',
        };
      })
    );

    return { success: true };
  };

  // Customers Management
  const addCustomer = (data: Omit<Customer, 'id' | 'createdAt'>): Customer => {
    const newCustomer: Customer = {
      ...data,
      id: `CUST-${String(customers.length + 1).padStart(3, '0')}`,
      createdAt: new Date().toISOString(),
    };
    setCustomers((prev) => [newCustomer, ...prev]);
    return newCustomer;
  };

  const updateCustomer = (updatedCust: Customer) => {
    setCustomers((prev) => prev.map((c) => (c.id === updatedCust.id ? updatedCust : c)));
  };

  const deleteCustomer = (id: string) => {
    setCustomers((prev) => prev.filter((c) => c.id !== id));
  };

  // Services Management
  const addService = (data: Omit<ServiceMaster, 'id'>): ServiceMaster => {
    const newService: ServiceMaster = {
      ...data,
      id: `SRV-${String(services.length + 1).padStart(3, '0')}`,
    };
    setServices((prev) => [...prev, newService]);
    return newService;
  };

  const updateService = (updatedSrv: ServiceMaster) => {
    setServices((prev) => prev.map((s) => (s.id === updatedSrv.id ? updatedSrv : s)));
  };

  const deleteService = (id: string) => {
    setServices((prev) => prev.filter((s) => s.id !== id));
  };

  // Expenses Management
  const addExpense = (expense: Expense): { success: boolean; error?: string } => {
    const cleanId = expense.id.trim();
    if (!cleanId) {
      return { success: false, error: 'ID Pengeluaran tidak boleh kosong.' };
    }

    if (!isExpenseIdAvailable(cleanId)) {
      return { success: false, error: `ID Pengeluaran "${cleanId}" sudah pernah digunakan.` };
    }

    if (expense.amount <= 0) {
      return { success: false, error: 'Nominal pengeluaran harus lebih besar dari Rp 0.' };
    }

    setExpenses((prev) => [{ ...expense, id: cleanId }, ...prev]);
    return { success: true };
  };

  const deleteExpense = (id: string) => {
    setExpenses((prev) => prev.filter((e) => e.id !== id));
  };

  // Settings & Storage Tools
  const updateSettings = (newSettings: Partial<AppSettings>) => {
    setSettings((prev) => ({ ...prev, ...newSettings }));
  };

  const resetToDemo = () => {
    setSettings(INITIAL_SETTINGS);
    setServices(INITIAL_SERVICES);
    setCustomers(INITIAL_CUSTOMERS);
    setTransactions(INITIAL_TRANSACTIONS);
    setPayments(INITIAL_PAYMENTS);
    setExpenses(INITIAL_EXPENSES);
  };

  const exportDataJSON = (): string => {
    const payload = {
      exportDate: new Date().toISOString(),
      appVersion: 'PLIS 1.0.0',
      settings,
      services,
      customers,
      transactions,
      payments,
      expenses,
    };
    return JSON.stringify(payload, null, 2);
  };

  const importDataJSON = (jsonStr: string): { success: boolean; message: string } => {
    try {
      const data = JSON.parse(jsonStr);
      if (!data.transactions && !data.services) {
        return { success: false, message: 'Format data JSON tidak valid untuk sistem PLIS.' };
      }
      if (data.settings) setSettings(data.settings);
      if (data.services) setServices(data.services);
      if (data.customers) setCustomers(data.customers);
      if (data.transactions) setTransactions(data.transactions);
      if (data.payments) setPayments(data.payments);
      if (data.expenses) setExpenses(data.expenses);
      return { success: true, message: 'Data cadangan berhasil dipulihkan.' };
    } catch {
      return { success: false, message: 'Gagal menguraikan berkas JSON. Pastikan file valid.' };
    }
  };

  return (
    <LaundryContext.Provider
      value={{
        activeTab,
        setActiveTab,
        viewportMode,
        setViewportMode,
        isMobileMenuOpen,
        setIsMobileMenuOpen,
        transactions,
        customers,
        services,
        payments,
        expenses,
        settings,
        selectedTransactionId,
        setSelectedTransactionId,
        receiptModalTransaction,
        setReceiptModalTransaction,
        isNewTxModalOpen,
        setIsNewTxModalOpen,
        generateNextTransactionId,
        isTransactionIdAvailable,
        generateNextExpenseId,
        isExpenseIdAvailable,
        addTransaction,
        updateTransaction,
        deleteTransaction,
        updateItemStatus,
        deliverItem,
        addPayment,
        addCustomer,
        updateCustomer,
        deleteCustomer,
        addService,
        updateService,
        deleteService,
        addExpense,
        deleteExpense,
        updateSettings,
        resetToDemo,
        exportDataJSON,
        importDataJSON,
      }}
    >
      {children}
    </LaundryContext.Provider>
  );
};

export const useLaundry = () => {
  const context = useContext(LaundryContext);
  if (!context) {
    throw new Error('useLaundry must be used within a LaundryProvider');
  }
  return context;
};
