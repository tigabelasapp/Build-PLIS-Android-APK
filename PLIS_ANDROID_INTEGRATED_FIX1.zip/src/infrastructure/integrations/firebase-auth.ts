import { getApp, getApps, initializeApp, type FirebaseApp } from 'firebase/app';
import {
  getAuth,
  GoogleAuthProvider,
  onAuthStateChanged,
  signInWithPopup,
  signOut,
  type User,
} from 'firebase/auth';

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID,
};

const requiredConfig = [
  firebaseConfig.apiKey,
  firebaseConfig.authDomain,
  firebaseConfig.projectId,
  firebaseConfig.appId,
];

export const isFirebaseAuthConfigured = requiredConfig.every(
  (value) => typeof value === 'string' && value.trim().length > 0,
);

let firebaseApp: FirebaseApp | null = null;

function getFirebaseAuth() {
  if (!isFirebaseAuthConfigured) return null;
  firebaseApp = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
  return getAuth(firebaseApp);
}

export function observeGoogleUser(callback: (user: User | null) => void) {
  const auth = getFirebaseAuth();
  if (!auth) {
    callback(null);
    return () => undefined;
  }
  return onAuthStateChanged(auth, callback);
}

export async function signInWithGoogle() {
  const auth = getFirebaseAuth();
  if (!auth) {
    throw new Error(
      'Login Google belum aktif. Lengkapi konfigurasi Firebase pada file .env.local terlebih dahulu.',
    );
  }
  const provider = new GoogleAuthProvider();
  provider.setCustomParameters({ prompt: 'select_account' });
  return signInWithPopup(auth, provider);
}

export async function signOutGoogle() {
  const auth = getFirebaseAuth();
  if (!auth) throw new Error('Konfigurasi Firebase belum tersedia.');
  await signOut(auth);
}
