/** Implementasi penyimpanan browser. Tidak berisi aturan bisnis PLIS. */
export function readLocalValue<T>(key: string, fallback: T): T {
  try {
    if (typeof window === 'undefined' || !window.localStorage) return fallback;
    const raw = window.localStorage.getItem(key);
    if (raw === null) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    // Storage tidak tersedia atau JSON rusak: jangan membuat aplikasi crash.
    return fallback;
  }
}

export function writeLocalValue<T>(key: string, value: T): boolean {
  try {
    if (typeof window === 'undefined' || !window.localStorage) return false;
    window.localStorage.setItem(key, JSON.stringify(value));
    return true;
  } catch {
    // Termasuk quota penuh dan akses storage yang ditolak browser.
    return false;
  }
}
