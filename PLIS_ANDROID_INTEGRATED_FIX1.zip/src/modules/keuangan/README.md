# Keuangan

> Status: belum dimigrasikan; implementasi aktif di `PaymentsView.tsx`, `ExpensesView.tsx`, `ReportsView.tsx`, dan `LaundryContext.tsx`.

## Tujuan
Mengelola pembayaran, pengeluaran, sisa tagihan, dan ringkasan laporan keuangan.

## Data yang dimiliki
`PaymentRecord` dan `Expense`; status pembayaran dan jumlah dibayar pada `Transaction` harus direkonsiliasi.

## Fungsi publik
Belum ada. API publik dibuat melalui `index.ts` setelah service/repository tersedia.

## Bergantung pada
Transaksi dan repository penyimpanan.

## Dipakai oleh
Dashboard, pembayaran, pengeluaran, dan laporan.

## Aturan bisnis
Pembayaran tidak boleh terduplikasi; total pembayaran terkait harus konsisten dengan `Transaction.paidAmount` dan `paymentStatus`. ID pengeluaran tetap permanen.

## Pengujian
Uji pembayaran sebagian/lunas, pembayaran berulang, sisa tagihan, pengeluaran, dan agregat laporan.

## Batasan yang diketahui
Pembayaran dan transaksi berada dalam penyimpanan lokal yang sama, tetapi belum ada transaksi atomik database atau sinkronisasi cloud.
