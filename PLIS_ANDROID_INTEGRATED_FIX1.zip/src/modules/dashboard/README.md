# Dashboard

> Status: belum dimigrasikan; implementasi aktif masih di `src/components/views/DashboardView.tsx`.

## Tujuan
Menampilkan ringkasan operasional berdasarkan transaksi, pembayaran, dan pengeluaran.

## Data yang dimiliki
Tidak memiliki data bisnis primer; membaca agregat transaksi, pembayaran, dan pengeluaran.

## Fungsi publik
Belum ada. API publik dibuat melalui `index.ts` saat migrasi implementasi dimulai.

## Bergantung pada
Saat ini membaca state melalui `useLaundry()` dari `src/context/LaundryContext.tsx`.

## Dipakai oleh
Tab dashboard di `src/App.tsx`.

## Aturan bisnis
Angka ringkasan harus dihitung dari data sumber dan tidak boleh menjadi sumber data transaksi baru.

## Pengujian
Uji angka ringkasan terhadap fixture transaksi/pembayaran/pengeluaran yang diketahui.

## Batasan yang diketahui
Belum memiliki service/repository terpisah; jangan membuat implementasi kedua di folder ini sebelum migrasi.
