# Akun

> Status: autentikasi Google disiapkan; integrasi memerlukan konfigurasi dan belum diverifikasi end-to-end.

## Tujuan
Mengidentifikasi pengguna melalui Firebase Authentication.

## Data yang dimiliki
Identitas sesi Firebase Auth; bukan data transaksi, pelanggan, atau hak akses bisnis yang otoritatif.

## Fungsi publik
Saat ini helper di `src/infrastructure/integrations/firebase-auth.ts`: `observeGoogleUser`, `signInWithGoogle`, `signOutGoogle`, `isFirebaseAuthConfigured`. Pemindahan ke pintu publik `index.ts` belum dilakukan.

## Bergantung pada
Firebase Authentication dan environment `VITE_FIREBASE_*`.

## Dipakai oleh
`src/components/layout/MobileDrawer.tsx` di Menu Tambahan PLIS.

## Aturan bisnis
Login berhasil tidak berarti data tersinkronisasi dan tidak otomatis memberikan peran owner/karyawan. Otorisasi data harus ditegakkan di backend/database.

## Pengujian
Uji konfigurasi kosong, login berhasil, pembatalan popup, status setelah reload, dan logout.

## Batasan yang diketahui
Firestore dan sinkronisasi antarperangkat belum diterapkan; login end-to-end belum terverifikasi.
