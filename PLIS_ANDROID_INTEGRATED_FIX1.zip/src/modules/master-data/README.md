# Master Data

> Status: belum dimigrasikan; implementasi aktif masih di `src/components/views/MasterDataView.tsx` dan tipe/data awal terkait.

## Tujuan
Mengelola data referensi yang dipakai ketika transaksi dibuat, terutama layanan, tarif, dan satuan.

## Data yang dimiliki
`ServiceMaster`: `id`, `name`, `category`, `unit`, `pricePerUnit`, `defaultDurationHours`, `description?`.

## Fungsi publik
Belum ada. API publik dibuat melalui `index.ts` setelah migrasi.

## Bergantung pada
Saat ini memakai `useLaundry()` dan tipe di `src/types/index.ts`.

## Dipakai oleh
Form transaksi baru, detail transaksi, dan laporan yang menggunakan snapshot layanan.

## Aturan bisnis
Perubahan tarif master tidak boleh mengubah harga/satuan pada transaksi historis.

## Pengujian
Uji CRUD master dan pastikan transaksi lama tetap memiliki snapshot harga dan satuan.

## Batasan yang diketahui
Kategori dan satuan saat ini masih berupa tipe/konstanta; struktur hierarki kategori → klasifikasi → layanan belum dibangun sebagai entitas tersendiri.
