# Transaksi

> Status: belum dimigrasikan; implementasi aktif tersebar di `TransactionsView.tsx`, `NewTransactionModal.tsx`, `TransactionDetailModal.tsx`, dan `LaundryContext.tsx`.

## Tujuan
Membuat dan mengelola transaksi penerimaan cucian beserta item layanan dan nilai tagihannya.

## Data yang dimiliki
`Transaction` dan `OrderItem`; field lengkap tercantum di `docs/DATA_MODEL.md`.

## Fungsi publik
Belum ada. API publik dibuat melalui `index.ts` setelah service/repository tersedia.

## Bergantung pada
Master Data untuk referensi layanan; Keuangan untuk pencatatan pembayaran; repository untuk penyimpanan.

## Dipakai oleh
Dashboard, Operasional, Pembayaran, Nota, dan Laporan.

## Aturan bisnis
ID transaksi unik dan permanen. Harga/unit item adalah snapshot. Total, diskon, pembayaran, dan status harus konsisten.

## Pengujian
Uji pembuatan/edit transaksi, benturan ID, item kosong, total, diskon, pembayaran awal, serta snapshot master.

## Batasan yang diketahui
Validasi dan CRUD masih bercampur dalam `LaundryContext.tsx`; Firestore belum aktif.
