# Domain modules — scaffolding dokumentasi

Folder ini adalah peta tujuan refactor dan dokumentasi domain. **Implementasi fitur aktif masih berada di lokasi yang tercantum dalam `docs/PROJECT_MAP.md` dan `docs/MODULES.md`.** Folder modul ini belum menjadi batas dependensi yang ditegakkan oleh kode.

README per domain mencatat tujuan, pemilik data, fungsi publik yang direncanakan/tersedia, dependensi, pemakai, aturan bisnis, tes, dan batasan. Jangan menafsirkan README ini sebagai bukti bahwa API `index.ts`, service, atau repository domain sudah tersedia.

## Aturan migrasi
1. Baca `docs/AUDIT_REPORT.md` dan `docs/REFACTOR_PLAN.md`.
2. Petakan semua import dan perilaku pada kode aktif.
3. Pindahkan satu domain dalam satu iterasi.
4. Definisikan API publik di `index.ts`; modul lain tidak mengimpor file internalnya.
5. Pisahkan `page/component → service → repository → infrastructure`.
6. Jalankan `npm run lint`, `npm run build`, dan tes regresi domain terkait sebelum menandai modul aktif.
7. Jangan membuat salinan paralel dari fitur yang masih berada di `src/components/`.
