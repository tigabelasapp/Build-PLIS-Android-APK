# Nota

> Status: belum dimigrasikan; implementasi aktif di `src/components/modals/ThermalReceiptModal.tsx`.

## Tujuan
Menampilkan dan mencetak bukti transaksi untuk pelanggan.

## Data yang dimiliki
Tidak memiliki transaksi primer; membaca snapshot transaksi tersimpan dan `AppSettings` untuk header/footer.

## Fungsi publik
Belum ada. API publik dibuat melalui `index.ts` setelah migrasi.

## Bergantung pada
Transaksi dan Pengaturan melalui data/context yang tersedia.

## Dipakai oleh
Alur detail transaksi dan cetak nota.

## Aturan bisnis
Bagian transaksi pada nota berasal dari transaksi tersimpan dan tidak boleh menjadi jalur untuk mengedit nilai transaksi.

## Pengujian
Uji nomor nota, identitas pelanggan, item, harga, total, pembayaran, sisa, dan lebar cetak yang dipilih.

## Batasan yang diketahui
Integrasi berbagi WhatsApp/print harus diuji pada perangkat nyata; nota bukan data cloud tersendiri saat ini.
