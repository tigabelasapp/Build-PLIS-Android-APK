# Operasional

> Status: belum dimigrasikan; implementasi aktif di `src/components/views/ProcessTrackingView.tsx`.

## Tujuan
Melacak status item laundry dari penerimaan sampai diserahkan.

## Data yang dimiliki
Tidak memiliki transaksi primer terpisah; memperbarui `OrderItem.status`, `completedAt`, dan `deliveredAt` dalam transaksi.

## Fungsi publik
Belum ada. API publik dibuat melalui `index.ts` setelah migrasi.

## Bergantung pada
Transaksi melalui API publik yang akan ditetapkan.

## Dipakai oleh
Dashboard, tampilan proses laundry, dan laporan.

## Aturan bisnis
Transisi status harus memakai nilai domain terpusat dan tidak boleh mengganti ID transaksi atau ID item.

## Pengujian
Uji transisi status, waktu selesai/penyerahan, dan persistensi setelah reload.

## Batasan yang diketahui
Status saat ini disimpan per item dalam transaksi lokal; aturan transisi formal belum dipisahkan ke service.
