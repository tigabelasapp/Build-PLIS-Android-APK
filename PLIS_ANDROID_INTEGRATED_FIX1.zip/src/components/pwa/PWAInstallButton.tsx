import React, { useState } from 'react';
import { usePWAInstall } from '../../hooks/usePWAInstall';
import { Download, Smartphone, X, CheckCircle2, Share } from 'lucide-react';

export const PWAInstallButton: React.FC = () => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showGuideModal, setShowGuideModal] = useState(false);

  // If already running standalone on phone home screen, hide button
  if (isInstalled) {
    return null;
  }

  const handleInstallClick = async () => {
    if (isInstallable) {
      await install();
    } else {
      setShowGuideModal(true);
    }
  };

  return (
    <>
      <button
        onClick={handleInstallClick}
        className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 rounded-lg text-xs font-bold transition-all cursor-pointer shadow-xs"
        title="Pasang aplikasi ini ke layar utama HP Anda"
      >
        <Download className="w-3.5 h-3.5 text-emerald-600" />
        <span>Pasang ke HP</span>
      </button>

      {/* Guide Modal for iOS & Manual Installation */}
      {showGuideModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs no-print">
          <div className="bg-white rounded-2xl shadow-2xl max-w-sm w-full p-5 border border-slate-200 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <Smartphone className="w-5 h-5 text-emerald-600" />
                <h3 className="text-sm font-bold text-slate-900">
                  Pasang PLIS ke Layar HP
                </h3>
              </div>
              <button
                onClick={() => setShowGuideModal(false)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="text-xs text-slate-600 space-y-3 leading-relaxed">
              <p>
                Aplikasi ini mendukung <strong>Progressive Web App (PWA)</strong>, sehingga dapat dipasang langsung ke layar utama HP Android maupun iPhone tanpa perlu download dari Play Store:
              </p>

              {isIOS ? (
                /* iOS Safari Guide */
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                  <div className="font-semibold text-slate-900 flex items-center gap-1.5">
                    <Share className="w-4 h-4 text-emerald-600" />
                    <span>Langkah di iPhone / Safari:</span>
                  </div>
                  <ol className="list-decimal list-inside space-y-1.5 text-slate-600 text-[11px]">
                    <li>Ketuk ikon <strong>Bagikan / Share</strong> (kotak panah ke atas) di bilah bawah Safari.</li>
                    <li>Gulir ke bawah dan pilih <strong>"Tambahkan ke Layar Utama" (Add to Home Screen)</strong>.</li>
                    <li>Ketuk <strong>Tambah</strong>. Ikon PLIS akan muncul di menu HP Anda!</li>
                  </ol>
                </div>
              ) : (
                /* Android Chrome Guide */
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                  <div className="font-semibold text-slate-900">
                    Langkah di Android / Chrome:
                  </div>
                  <ol className="list-decimal list-inside space-y-1.5 text-slate-600 text-[11px]">
                    <li>Buka menu titik tiga (<strong>⋮</strong>) di pojok kanan atas browser Chrome.</li>
                    <li>Pilih opsi <strong>"Pasang aplikasi"</strong> atau <strong>"Tambahkan ke Layar Utama"</strong>.</li>
                    <li>Konfirmasi pemasangan. Aplikasi PLIS siap dibuka seperti aplikasi native!</li>
                  </ol>
                </div>
              )}

              <div className="p-2.5 bg-emerald-50 rounded-lg border border-emerald-200 text-emerald-900 text-[11px] flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Setelah dipasang, aplikasi dapat dibuka fullscreen dan bekerja offline.</span>
              </div>
            </div>

            <button
              onClick={() => setShowGuideModal(false)}
              className="w-full py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-semibold cursor-pointer"
            >
              Mengerti, Tutup
            </button>
          </div>
        </div>
      )}
    </>
  );
};
