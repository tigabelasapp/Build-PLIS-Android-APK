import React, { useState } from 'react';
import { useLaundry } from '../../context/LaundryContext';
import { formatRupiah } from '../../utils/formatters';
import {
  BarChart3,
  TrendingUp,
  TrendingDown,
  Download,
  Filter,
  DollarSign,
  PieChart,
  ShoppingBag,
  CreditCard,
} from 'lucide-react';

export const ReportsView: React.FC = () => {
  const { transactions, payments, expenses, services } = useLaundry();

  const [periodFilter, setPeriodFilter] = useState<'semua' | 'hari_ini' | '7_hari' | 'bulan_ini'>('semua');

  // Filter based on period
  const filterByDate = (dateStr: string) => {
    if (periodFilter === 'semua') return true;
    const d = new Date(dateStr);
    const now = new Date();

    if (periodFilter === 'hari_ini') {
      return (
        d.getDate() === now.getDate() &&
        d.getMonth() === now.getMonth() &&
        d.getFullYear() === now.getFullYear()
      );
    }

    if (periodFilter === '7_hari') {
      const diffTime = Math.abs(now.getTime() - d.getTime());
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      return diffDays <= 7;
    }

    if (periodFilter === 'bulan_ini') {
      return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
    }

    return true;
  };

  const filteredTx = transactions.filter((t) => filterByDate(t.createdAt));
  const filteredPayments = payments.filter((p) => filterByDate(p.date));
  const filteredExpenses = expenses.filter((e) => filterByDate(e.date));

  // Financial calculations
  const totalSalesBilled = filteredTx.reduce((sum, t) => sum + t.grandTotal, 0);
  const totalCashIncome = filteredPayments.reduce((sum, p) => sum + p.amount, 0);
  const totalExpensesCost = filteredExpenses.reduce((sum, e) => sum + e.amount, 0);
  const netProfit = totalCashIncome - totalExpensesCost;
  const profitMargin = totalCashIncome > 0 ? ((netProfit / totalCashIncome) * 100).toFixed(1) : '0';

  // Receivables
  const totalReceivables = filteredTx.reduce((sum, t) => sum + Math.max(0, t.grandTotal - t.paidAmount), 0);

  // Popular Services aggregation
  const serviceStats: { [key: string]: { name: string; count: number; revenue: number } } = {};
  filteredTx.forEach((tx) => {
    tx.items.forEach((item) => {
      if (!serviceStats[item.serviceId]) {
        serviceStats[item.serviceId] = {
          name: item.serviceName,
          count: 0,
          revenue: 0,
        };
      }
      serviceStats[item.serviceId].count += item.quantity;
      serviceStats[item.serviceId].revenue += item.subtotal;
    });
  });

  const topServices = Object.values(serviceStats).sort((a, b) => b.revenue - a.revenue);

  // Expense Categories aggregation
  const expenseCatStats: { [key: string]: number } = {};
  filteredExpenses.forEach((exp) => {
    expenseCatStats[exp.category] = (expenseCatStats[exp.category] || 0) + exp.amount;
  });

  // Export CSV
  const handleExportCSV = () => {
    let csv = 'No Nota,Tanggal,Pelanggan,Total Tagihan,Terbayar,Status\n';
    filteredTx.forEach((t) => {
      csv += `"${t.id}","${t.createdAt}","${t.customerName}",${t.grandTotal},${t.paidAmount},"${t.paymentStatus}"\n`;
    });

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `laporan-laundry-${periodFilter}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-5">
      {/* View Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900">
            Laporan Keuangan & Operasional Usaha
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Analisis ringkasan transaksi penjualan, penerimaan kas nyata, pengeluaran, dan laba bersih.
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-white hover:bg-slate-100 text-slate-700 text-xs font-semibold rounded-lg border border-slate-300 transition-colors cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Ekspor CSV</span>
          </button>
        </div>
      </div>

      {/* Period Selector Bar */}
      <div className="bg-white p-3 rounded-xl border border-slate-200/80 shadow-xs flex items-center justify-between">
        <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">
          Filter Periode Laporan:
        </span>

        <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg text-xs font-medium">
          <button
            onClick={() => setPeriodFilter('semua')}
            className={`px-3 py-1 rounded-md transition-colors ${
              periodFilter === 'semua'
                ? 'bg-white text-slate-900 font-bold shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Semua Waktu
          </button>
          <button
            onClick={() => setPeriodFilter('bulan_ini')}
            className={`px-3 py-1 rounded-md transition-colors ${
              periodFilter === 'bulan_ini'
                ? 'bg-white text-slate-900 font-bold shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Bulan Ini
          </button>
          <button
            onClick={() => setPeriodFilter('7_hari')}
            className={`px-3 py-1 rounded-md transition-colors ${
              periodFilter === '7_hari'
                ? 'bg-white text-slate-900 font-bold shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            7 Hari Terakhir
          </button>
          <button
            onClick={() => setPeriodFilter('hari_ini')}
            className={`px-3 py-1 rounded-md transition-colors ${
              periodFilter === 'hari_ini'
                ? 'bg-white text-slate-900 font-bold shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Hari Ini
          </button>
        </div>
      </div>

      {/* Executive Financial Scorecard */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Omzet Tagihan */}
        <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-xs">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-500 block">
            Nilai Omzet Nota Terbit
          </span>
          <div className="text-2xl font-bold font-mono tracking-tight text-slate-900 mt-2 tabular-nums">
            {formatRupiah(totalSalesBilled)}
          </div>
          <p className="text-[11px] text-slate-500 mt-1">
            {filteredTx.length} nota transaksi diterbitkan
          </p>
        </div>

        {/* Real Cash Inflow */}
        <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-xs">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-500 block">
            Pemasukan Kas Nyata
          </span>
          <div className="text-2xl font-bold font-mono tracking-tight text-emerald-600 mt-2 tabular-nums">
            {formatRupiah(totalCashIncome)}
          </div>
          <p className="text-[11px] text-emerald-700 mt-1 font-medium">
            Kas nyata masuk ke kasir/rekening
          </p>
        </div>

        {/* Total Expenses */}
        <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-xs">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-500 block">
            Total Pengeluaran Usaha
          </span>
          <div className="text-2xl font-bold font-mono tracking-tight text-rose-700 mt-2 tabular-nums">
            {formatRupiah(totalExpensesCost)}
          </div>
          <p className="text-[11px] text-rose-700/80 mt-1">
            Bahan baku, listrik & operasional
          </p>
        </div>

        {/* Net Profit */}
        <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-xs">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-500 block">
            Estimasi Laba Bersih Kas
          </span>
          <div className={`text-2xl font-bold font-mono tracking-tight mt-2 tabular-nums ${netProfit >= 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
            {formatRupiah(netProfit)}
          </div>
          <p className="text-[11px] text-slate-500 mt-1">
            Margin: <strong>{profitMargin}%</strong> dari kas masuk
          </p>
        </div>
      </div>

      {/* Analytics Breakdown: 2 Columns */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Left: Top Services by Revenue */}
        <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold uppercase tracking-wider text-slate-800">
              Layanan Terlaris & Kontribusi Omzet
            </h2>
            <ShoppingBag className="w-4 h-4 text-slate-400" />
          </div>

          {topServices.length === 0 ? (
            <div className="text-center py-8 text-xs text-slate-400">
              Belum ada data penjualan pada periode ini.
            </div>
          ) : (
            <div className="space-y-3">
              {topServices.slice(0, 5).map((srv, idx) => {
                const percent = totalSalesBilled > 0 ? (srv.revenue / totalSalesBilled) * 100 : 0;
                return (
                  <div key={idx} className="space-y-1.5 text-xs">
                    <div className="flex justify-between items-center">
                      <span className="font-semibold text-slate-900 truncate pr-2">
                        {idx + 1}. {srv.name}
                      </span>
                      <span className="font-mono font-bold text-slate-900 tabular-nums shrink-0">
                        {formatRupiah(srv.revenue)}
                      </span>
                    </div>

                    {/* Progress Bar */}
                    <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
                      <div
                        className="bg-emerald-600 h-1.5 rounded-full"
                        style={{ width: `${Math.min(100, Math.max(5, percent))}%` }}
                      />
                    </div>

                    <div className="flex justify-between text-[11px] text-slate-500">
                      <span>Total Pengerjaan: {srv.count} kali</span>
                      <span className="font-mono">{percent.toFixed(1)}% dari total omzet</span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Right: Expense Categories Breakdown */}
        <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold uppercase tracking-wider text-slate-800">
              Struktur Beban & Pengeluaran Usaha
            </h2>
            <PieChart className="w-4 h-4 text-slate-400" />
          </div>

          {Object.keys(expenseCatStats).length === 0 ? (
            <div className="text-center py-8 text-xs text-slate-400">
              Belum ada data pengeluaran pada periode ini.
            </div>
          ) : (
            <div className="space-y-3">
              {Object.entries(expenseCatStats).map(([cat, total], idx) => {
                const percent = totalExpensesCost > 0 ? (total / totalExpensesCost) * 100 : 0;
                return (
                  <div key={idx} className="space-y-1.5 text-xs">
                    <div className="flex justify-between items-center">
                      <span className="font-semibold text-slate-900">{cat}</span>
                      <span className="font-mono font-bold text-rose-700 tabular-nums">
                        {formatRupiah(total)}
                      </span>
                    </div>

                    <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
                      <div
                        className="bg-rose-500 h-1.5 rounded-full"
                        style={{ width: `${Math.min(100, Math.max(5, percent))}%` }}
                      />
                    </div>

                    <div className="flex justify-end text-[11px] text-slate-500 font-mono">
                      <span>{percent.toFixed(1)}% dari total beban</span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
