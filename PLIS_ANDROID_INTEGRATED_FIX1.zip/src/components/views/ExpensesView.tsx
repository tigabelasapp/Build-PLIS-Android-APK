import React, { useState, useEffect } from 'react';
import { useLaundry } from '../../context/LaundryContext';
import { Expense, ExpenseCategory } from '../../types';
import { formatRupiah, formatDateTime } from '../../utils/formatters';
import {
  Wallet,
  Plus,
  Search,
  Filter,
  Trash2,
  X,
  AlertCircle,
  CheckCircle2,
  Tag,
} from 'lucide-react';

const CATEGORIES: ExpenseCategory[] = [
  'Bahan Baku (Sabun/Parfum)',
  'Operasional & Listrik',
  'Gaji Karyawan',
  'Perawatan & Servis Mesin',
  'Sewa Tempat',
  'Transport & Kurir',
  'Lain-lain',
];

export const ExpensesView: React.FC = () => {
  const {
    expenses,
    addExpense,
    deleteExpense,
    generateNextExpenseId,
    isExpenseIdAvailable,
  } = useLaundry();

  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('semua');
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Form states
  const [expId, setExpId] = useState('');
  const [isManualId, setIsManualId] = useState(false);
  const [idValidation, setIdValidation] = useState({ isValid: true, text: '' });
  const [date, setDate] = useState('');
  const [category, setCategory] = useState<ExpenseCategory>('Bahan Baku (Sabun/Parfum)');
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState<number>(0);
  const [recipient, setRecipient] = useState('');
  const [notes, setNotes] = useState('');
  const [formError, setFormError] = useState('');

  // Total expenses calculation
  const totalExpenseSum = expenses.reduce((sum, e) => sum + e.amount, 0);

  // Filtered expenses
  const filteredExpenses = expenses.filter((e) => {
    if (selectedCategory !== 'semua' && e.category !== selectedCategory) {
      return false;
    }
    if (search.trim()) {
      const q = search.toLowerCase();
      return (
        e.id.toLowerCase().includes(q) ||
        e.description.toLowerCase().includes(q) ||
        e.recipient.toLowerCase().includes(q) ||
        e.category.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const handleOpenModal = () => {
    const nextId = generateNextExpenseId();
    setExpId(nextId);
    setIsManualId(false);
    setIdValidation({ isValid: true, text: 'ID Pengeluaran unik & siap diterbitkan.' });

    // Set today's date formatted for datetime-local
    const now = new Date();
    const pad = (n: number) => String(n).padStart(2, '0');
    setDate(`${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}T${pad(now.getHours())}:${pad(now.getMinutes())}`);

    setCategory('Bahan Baku (Sabun/Parfum)');
    setDescription('');
    setAmount(0);
    setRecipient('');
    setNotes('');
    setFormError('');
    setIsModalOpen(true);
  };

  // Validate ID uniqueness dynamically
  useEffect(() => {
    if (!isModalOpen) return;
    const clean = expId.trim();
    if (!clean) {
      setIdValidation({ isValid: false, text: 'ID Pengeluaran tidak boleh kosong.' });
      return;
    }
    const avail = isExpenseIdAvailable(clean);
    if (avail) {
      setIdValidation({ isValid: true, text: 'ID unik dan siap dicatat.' });
    } else {
      setIdValidation({
        isValid: false,
        text: `PERINGATAN: ID "${clean}" sudah pernah digunakan!`,
      });
    }
  }, [expId, isModalOpen]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    if (!description.trim()) {
      setFormError('Keterangan pengeluaran wajib diisi.');
      return;
    }

    if (amount <= 0) {
      setFormError('Nominal pengeluaran harus lebih besar dari Rp 0.');
      return;
    }

    if (!idValidation.isValid) {
      setFormError(idValidation.text);
      return;
    }

    const isoDate = date ? new Date(date).toISOString() : new Date().toISOString();

    const newExpense: Expense = {
      id: expId.trim().toUpperCase(),
      date: isoDate,
      category,
      description: description.trim(),
      amount: Number(amount),
      recipient: recipient.trim() || '-',
      notes: notes.trim() || undefined,
    };

    const res = addExpense(newExpense);
    if (!res.success) {
      setFormError(res.error || 'Gagal menyimpan pengeluaran.');
      return;
    }

    setIsModalOpen(false);
  };

  const handleDelete = (exp: Expense) => {
    if (confirm(`Hapus pengeluaran "${exp.description}" (${exp.id}) senilai ${formatRupiah(exp.amount)}?`)) {
      deleteExpense(exp.id);
    }
  };

  return (
    <div className="space-y-5">
      {/* View Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900">
            Pencatatan Pengeluaran Usaha
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Mencatat biaya operasional, bahan baku, listrik, dan nota keluar dengan ID permanen unik.
          </p>
        </div>

        <button
          onClick={handleOpenModal}
          className="flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-lg shadow-xs transition-colors cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>+ Catat Pengeluaran Baru</span>
        </button>
      </div>

      {/* Overview Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-xs sm:col-span-1">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-500 block">
            Total Seluruh Pengeluaran
          </span>
          <div className="text-2xl font-bold font-mono tracking-tight text-rose-700 mt-2 tabular-nums">
            {formatRupiah(totalExpenseSum)}
          </div>
          <p className="text-[11px] text-slate-500 mt-1">
            Dari {expenses.length} nota pengeluaran tercatat
          </p>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-xs sm:col-span-2 flex flex-col justify-between">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-500 block mb-2">
            Kategori Pengeluaran Terbesar
          </span>
          <div className="flex flex-wrap gap-2">
            {CATEGORIES.slice(0, 4).map((cat) => {
              const catTotal = expenses
                .filter((e) => e.category === cat)
                .reduce((sum, e) => sum + e.amount, 0);

              return (
                <div key={cat} className="px-2.5 py-1.5 bg-slate-50 rounded-lg border border-slate-200 text-xs">
                  <span className="text-slate-600 block text-[10px] truncate max-w-[150px]">{cat}</span>
                  <span className="font-mono font-bold text-slate-900 tabular-nums">{formatRupiah(catTotal)}</span>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-3.5 rounded-xl border border-slate-200/80 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="relative flex-1 w-full max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Cari ID, keterangan, penerima, atau kategori..."
            className="w-full pl-9 pr-3 py-1.5 text-xs border border-slate-300 rounded-lg focus:ring-1 focus:ring-emerald-500 focus:outline-none"
          />
        </div>

        <div className="w-full sm:w-64">
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg bg-white focus:ring-1 focus:ring-emerald-500 focus:outline-none"
          >
            <option value="semua">Semua Kategori</option>
            {CATEGORIES.map((cat) => (
              <option key={cat} value={cat}>
                {cat}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Expenses Table */}
      <div className="bg-white rounded-xl border border-slate-200/80 shadow-xs overflow-hidden">
        {filteredExpenses.length === 0 ? (
          <div className="text-center py-12 text-xs text-slate-400">
            Belum ada data pengeluaran yang sesuai filter.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-50 text-slate-600 border-b border-slate-200 font-semibold">
                  <th className="py-3 px-4">No. Bukti / ID</th>
                  <th className="py-3 px-4">Tanggal</th>
                  <th className="py-3 px-4">Kategori Biaya</th>
                  <th className="py-3 px-4">Keterangan Pengeluaran</th>
                  <th className="py-3 px-4">Penerima Dana</th>
                  <th className="py-3 px-4 text-right">Nominal</th>
                  <th className="py-3 px-4 text-center w-16">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredExpenses.map((exp) => (
                  <tr key={exp.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3 px-4 font-mono font-bold text-slate-900">
                      {exp.id}
                    </td>
                    <td className="py-3 px-4 font-mono text-slate-500 text-[11px]">
                      {formatDateTime(exp.date)}
                    </td>
                    <td className="py-3 px-4">
                      <span className="text-[10px] px-2 py-0.5 rounded bg-slate-100 text-slate-700 font-medium">
                        {exp.category}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <span className="font-semibold text-slate-900 block">{exp.description}</span>
                      {exp.notes && (
                        <span className="text-[11px] text-slate-400 italic">{exp.notes}</span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-slate-700">
                      {exp.recipient}
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-bold tabular-nums text-rose-700 text-sm">
                      {formatRupiah(exp.amount)}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <button
                        onClick={() => handleDelete(exp)}
                        className="p-1.5 text-slate-400 hover:text-rose-600 rounded-md transition-colors cursor-pointer"
                        title="Hapus Pengeluaran"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Add Expense Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-2xl max-w-lg w-full overflow-hidden border border-slate-200">
            <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-200 bg-slate-50">
              <h3 className="text-sm font-bold text-slate-900">
                Pencatatan Pengeluaran Usaha Baru
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-5 space-y-4 text-xs">
              {formError && (
                <div className="p-2.5 bg-rose-50 border border-rose-200 rounded-lg text-rose-800 font-medium flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                  <span>{formError}</span>
                </div>
              )}

              {/* ID Pengeluaran Unik */}
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-2">
                <div className="flex justify-between items-center">
                  <label className="font-bold text-slate-700">
                    ID Pengeluaran Unik *
                  </label>
                  <button
                    type="button"
                    onClick={() => setIsManualId(!isManualId)}
                    className="text-[11px] text-emerald-700 hover:text-emerald-800 underline cursor-pointer"
                  >
                    {isManualId ? 'Gunakan Otomatis' : 'Ubah Manual'}
                  </button>
                </div>

                <input
                  type="text"
                  required
                  disabled={!isManualId}
                  value={expId}
                  onChange={(e) => setExpId(e.target.value.toUpperCase())}
                  className="w-full px-3 py-1.5 border border-slate-300 rounded font-mono font-bold tracking-wider text-slate-900 bg-white focus:outline-none"
                />

                <div className="text-[11px]">
                  {idValidation.isValid ? (
                    <span className="text-emerald-700 flex items-center gap-1 font-medium">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>{idValidation.text}</span>
                    </span>
                  ) : (
                    <span className="text-rose-600 flex items-center gap-1 font-semibold">
                      <AlertCircle className="w-3.5 h-3.5" />
                      <span>{idValidation.text}</span>
                    </span>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="font-medium text-slate-700 block mb-1">Tanggal *</label>
                  <input
                    type="datetime-local"
                    required
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full px-3 py-1.5 border border-slate-300 rounded font-mono focus:outline-none"
                  />
                </div>

                <div>
                  <label className="font-medium text-slate-700 block mb-1">Kategori Pengeluaran *</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as ExpenseCategory)}
                    className="w-full px-3 py-1.5 border border-slate-300 rounded focus:outline-none bg-white"
                  >
                    {CATEGORIES.map((cat) => (
                      <option key={cat} value={cat}>
                        {cat}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="font-medium text-slate-700 block mb-1">
                  Keterangan Pengeluaran *
                </label>
                <input
                  type="text"
                  required
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Contoh: Beli Deterjen Konsentrat 20L + Parfum Lavender"
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="font-medium text-slate-700 block mb-1">
                    Nominal Biaya (Rp) *
                  </label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={amount || ''}
                    onChange={(e) => setAmount(parseInt(e.target.value, 10) || 0)}
                    placeholder="0"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono font-bold text-slate-900 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="font-medium text-slate-700 block mb-1">
                    Penerima Dana / Toko Vendor
                  </label>
                  <input
                    type="text"
                    value={recipient}
                    onChange={(e) => setRecipient(e.target.value)}
                    placeholder="Contoh: Toko Kimia Surya"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="font-medium text-slate-700 block mb-1">
                  Catatan Tambahan (Opsional)
                </label>
                <input
                  type="text"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Nomor nota toko atau catatan rincian"
                  className="w-full px-3 py-1.5 border border-slate-300 rounded focus:outline-none"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-3 py-1.5 text-slate-600 hover:text-slate-800 text-xs font-medium cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={!idValidation.isValid}
                  className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-semibold rounded-lg shadow-xs cursor-pointer"
                >
                  Simpan Pengeluaran
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
