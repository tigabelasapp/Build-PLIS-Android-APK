import React, { useState } from 'react';
import { useLaundry } from '../../context/LaundryContext';
import {
  Settings,
  Save,
  Download,
  Upload,
  RotateCcw,
  Store,
  Printer,
  Hash,
  Database,
  CheckCircle2,
  FileSpreadsheet,
  Copy,
  Check,
  Code2,
  Eye,
  Info,
  FileText,
} from 'lucide-react';
import {
  exportTransactionsToCSV,
  exportCustomersToCSV,
  exportExpensesToCSV,
  exportPaymentsToCSV,
  downloadRawFile,
} from '../../utils/csvExport';

export const SettingsView: React.FC = () => {
  const {
    settings,
    updateSettings,
    resetToDemo,
    exportDataJSON,
    importDataJSON,
    transactions,
    customers,
    expenses,
    payments,
  } = useLaundry();

  const [storeName, setStoreName] = useState(settings.storeName);
  const [storeTagline, setStoreTagline] = useState(settings.storeTagline);
  const [storeAddress, setStoreAddress] = useState(settings.storeAddress);
  const [storePhone, setStorePhone] = useState(settings.storePhone);
  const [storeInstagram, setStoreInstagram] = useState(settings.storeInstagram || '');
  const [receiptFooter, setReceiptFooter] = useState(settings.receiptFooter);
  const [thermalWidth, setThermalWidth] = useState<'58mm' | '80mm'>(settings.thermalWidth);
  const [idPrefix, setIdPrefix] = useState(settings.idPrefix);
  const [expensePrefix, setExpensePrefix] = useState(settings.expensePrefix);

  const [savedBanner, setSavedBanner] = useState(false);
  const [importStatus, setImportStatus] = useState<string | null>(null);
  const [inspectorTab, setInspectorTab] = useState<'json' | 'csv_tx' | 'csv_cust' | 'csv_exp' | 'csv_pay'>('json');
  const [copied, setCopied] = useState(false);

  const getRawContent = () => {
    switch (inspectorTab) {
      case 'json':
        return exportDataJSON();
      case 'csv_tx':
        return exportTransactionsToCSV(transactions);
      case 'csv_cust':
        return exportCustomersToCSV(customers, transactions);
      case 'csv_exp':
        return exportExpensesToCSV(expenses);
      case 'csv_pay':
        return exportPaymentsToCSV(payments);
    }
  };

  const handleCopyContent = () => {
    const content = getRawContent();
    navigator.clipboard.writeText(content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleDownloadActiveTab = () => {
    const today = new Date().toISOString().slice(0, 10);
    switch (inspectorTab) {
      case 'json':
        handleDownloadBackup();
        break;
      case 'csv_tx':
        downloadRawFile(`plis-transaksi-${today}.csv`, exportTransactionsToCSV(transactions), 'text/csv;charset=utf-8;');
        break;
      case 'csv_cust':
        downloadRawFile(`plis-pelanggan-${today}.csv`, exportCustomersToCSV(customers), 'text/csv;charset=utf-8;');
        break;
      case 'csv_exp':
        downloadRawFile(`plis-pengeluaran-${today}.csv`, exportExpensesToCSV(expenses), 'text/csv;charset=utf-8;');
        break;
      case 'csv_pay':
        downloadRawFile(`plis-pembayaran-${today}.csv`, exportPaymentsToCSV(payments), 'text/csv;charset=utf-8;');
        break;
    }
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettings({
      storeName: storeName.trim() || 'PLIS',
      storeTagline: storeTagline.trim(),
      storeAddress: storeAddress.trim(),
      storePhone: storePhone.trim(),
      storeInstagram: storeInstagram.trim() || undefined,
      receiptFooter: receiptFooter.trim(),
      thermalWidth,
      idPrefix: idPrefix.trim().toUpperCase() || 'PLIS',
      expensePrefix: expensePrefix.trim().toUpperCase() || 'EXP',
    });

    setSavedBanner(true);
    setTimeout(() => setSavedBanner(false), 3000);
  };

  const handleDownloadBackup = () => {
    const jsonStr = exportDataJSON();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `cadangan-plis-laundry-${new Date().toISOString().slice(0, 10)}.json`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleImportFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) {
        const result = importDataJSON(content);
        setImportStatus(result.message);
        setTimeout(() => setImportStatus(null), 4000);
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const handleReset = () => {
    if (confirm('Apakah Anda yakin ingin mengatur ulang data ke data demo bawaan? Semua perubahan lokal akan digantikan oleh dataset demo.')) {
      resetToDemo();
      setSavedBanner(true);
      setTimeout(() => setSavedBanner(false), 3000);
    }
  };

  return (
    <div className="space-y-6 max-w-4xl">
      {/* Header */}
      <div>
        <h1 className="text-xl font-bold tracking-tight text-slate-900">
          Pengaturan Sistem & Identitas Usaha
        </h1>
        <p className="text-xs text-slate-500 mt-0.5">
          Konfigurasi profil outlet laundry, ukuran struk kasir, pola penomoran nota, dan cadangan data.
        </p>
      </div>

      {savedBanner && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 font-semibold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>Pengaturan berhasil disimpan dan langsung diterapkan ke sistem!</span>
        </div>
      )}

      {importStatus && (
        <div className="p-3 bg-sky-50 border border-sky-200 rounded-xl text-xs text-sky-800 font-semibold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-sky-600 shrink-0" />
          <span>{importStatus}</span>
        </div>
      )}

      <form onSubmit={handleSave} className="space-y-6">
        {/* Section 1: Profil Outlet */}
        <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-xs space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
            <Store className="w-4 h-4 text-emerald-600" />
            <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
              1. Identitas Usaha Laundry
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="font-semibold text-slate-700 block mb-1">
                Nama Usaha / Outlet *
              </label>
              <input
                type="text"
                required
                value={storeName}
                onChange={(e) => setStoreName(e.target.value)}
                placeholder="PLIS — Penggilas Laundry"
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-1 focus:ring-emerald-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="font-semibold text-slate-700 block mb-1">
                Slogan / Tagline
              </label>
              <input
                type="text"
                value={storeTagline}
                onChange={(e) => setStoreTagline(e.target.value)}
                placeholder="Penggilas Laundry Information System"
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-1 focus:ring-emerald-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="font-semibold text-slate-700 block mb-1">
                No. WhatsApp / Telepon Kasir *
              </label>
              <input
                type="text"
                required
                value={storePhone}
                onChange={(e) => setStorePhone(e.target.value)}
                placeholder="0812-9876-5432"
                className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono focus:ring-1 focus:ring-emerald-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="font-semibold text-slate-700 block mb-1">
                Instagram / Media Sosial (Opsional)
              </label>
              <input
                type="text"
                value={storeInstagram}
                onChange={(e) => setStoreInstagram(e.target.value)}
                placeholder="@penggilaslaundry.id"
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-1 focus:ring-emerald-500 focus:outline-none"
              />
            </div>

            <div className="md:col-span-2">
              <label className="font-semibold text-slate-700 block mb-1">
                Alamat Lengkap Outlet
              </label>
              <input
                type="text"
                value={storeAddress}
                onChange={(e) => setStoreAddress(e.target.value)}
                placeholder="Jl. Merdeka Raya No. 42..."
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-1 focus:ring-emerald-500 focus:outline-none"
              />
            </div>

            <div className="md:col-span-2">
              <label className="font-semibold text-slate-700 block mb-1">
                Pesan Footer pada Struk Kasir
              </label>
              <textarea
                rows={2}
                value={receiptFooter}
                onChange={(e) => setReceiptFooter(e.target.value)}
                placeholder="Terima kasih atas kunjungan Anda..."
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-1 focus:ring-emerald-500 focus:outline-none"
              />
            </div>
          </div>
        </div>

        {/* Section 2: Format Cetak Struk Kasir & Penomoran */}
        <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-xs space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
            <Printer className="w-4 h-4 text-emerald-600" />
            <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
              2. Format Cetak Struk Kasir & Penomoran Nota
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
            <div>
              <label className="font-semibold text-slate-700 block mb-1">
                Lebar Kertas Printer Thermal
              </label>
              <select
                value={thermalWidth}
                onChange={(e) => setThermalWidth(e.target.value as '58mm' | '80mm')}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white focus:outline-none font-mono"
              >
                <option value="80mm">80mm (Standar POS Kasir)</option>
                <option value="58mm">58mm (Printer Mini Bluetooth)</option>
              </select>
              <p className="text-[10px] text-slate-400 mt-1">
                Menyesuaikan pratinjau cetak agar pas di kertas thermal.
              </p>
            </div>

            <div>
              <label className="font-semibold text-slate-700 block mb-1">
                Prefix Nota Penjualan
              </label>
              <input
                type="text"
                value={idPrefix}
                onChange={(e) => setIdPrefix(e.target.value.toUpperCase())}
                placeholder="PLIS"
                className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono font-bold tracking-wider focus:outline-none"
              />
              <p className="text-[10px] text-slate-400 mt-1">
                Contoh: {idPrefix}-2610-001
              </p>
            </div>

            <div>
              <label className="font-semibold text-slate-700 block mb-1">
                Prefix Pengeluaran Usaha
              </label>
              <input
                type="text"
                value={expensePrefix}
                onChange={(e) => setExpensePrefix(e.target.value.toUpperCase())}
                placeholder="EXP"
                className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono font-bold tracking-wider focus:outline-none"
              />
              <p className="text-[10px] text-slate-400 mt-1">
                Contoh: {expensePrefix}-2610-001
              </p>
            </div>
          </div>
        </div>

        {/* Save Button */}
        <div className="flex justify-end">
          <button
            type="submit"
            className="flex items-center gap-2 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-xs transition-colors cursor-pointer"
          >
            <Save className="w-4 h-4" />
            <span>Simpan Perubahan Pengaturan</span>
          </button>
        </div>
      </form>

      {/* Section 3: Pusat Data Mentah (Raw Data Center), Ekspor & Cadangan */}
      <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-xs space-y-5">
        <div className="flex items-center justify-between pb-2 border-b border-slate-100 flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <Database className="w-4 h-4 text-emerald-600" />
            <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
              3. Pusat Data Mentah (Raw Data), Ekspor & Cadangan
            </h2>
          </div>
          <span className="text-[11px] text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full font-semibold border border-emerald-200">
            Tersimpan Aman di Browser (LocalStorage)
          </span>
        </div>

        <p className="text-xs text-slate-600 leading-relaxed">
          Semua data transaksi, riwayat pengerjaan per-item, profil pelanggan, mutasi kas, dan pengeluaran tersimpan rapi secara lokal. Anda dapat mengunduh atau menyalin data mentah ini kapan saja dalam format <strong>CSV (siap buka di Excel / Google Sheets)</strong> maupun <strong>JSON utuh (backup sistem)</strong>.
        </p>

        {/* 1-Click Raw Data Download Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {/* Card 1: CSV Transaksi */}
          <div className="p-3.5 bg-slate-50 hover:bg-slate-100/80 rounded-xl border border-slate-200 transition-colors flex flex-col justify-between space-y-3">
            <div>
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                  <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
                  Data Transaksi
                </span>
                <span className="text-[10px] bg-white px-1.5 py-0.5 rounded border border-slate-200 text-slate-600 font-mono">
                  {transactions.length} baris
                </span>
              </div>
              <p className="text-[11px] text-slate-500 mt-1">
                Tabel nota, rincian cucian, tagihan, terbayar, sisa utang & status pengerjaan.
              </p>
            </div>
            <button
              type="button"
              onClick={() => {
                const today = new Date().toISOString().slice(0, 10);
                downloadRawFile(`plis-transaksi-${today}.csv`, exportTransactionsToCSV(transactions), 'text/csv;charset=utf-8;');
              }}
              className="w-full flex items-center justify-center gap-1.5 py-1.5 text-xs font-semibold bg-white hover:bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-lg shadow-2xs transition-colors cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Unduh CSV (Excel)</span>
            </button>
          </div>

          {/* Card 2: CSV Pelanggan */}
          <div className="p-3.5 bg-slate-50 hover:bg-slate-100/80 rounded-xl border border-slate-200 transition-colors flex flex-col justify-between space-y-3">
            <div>
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                  <FileSpreadsheet className="w-4 h-4 text-sky-600" />
                  Buku Pelanggan
                </span>
                <span className="text-[10px] bg-white px-1.5 py-0.5 rounded border border-slate-200 text-slate-600 font-mono">
                  {customers.length} kontak
                </span>
              </div>
              <p className="text-[11px] text-slate-500 mt-1">
                Buku kontak pelanggan, no WhatsApp, alamat, total nota, & nominal belanja.
              </p>
            </div>
            <button
              type="button"
              onClick={() => {
                const today = new Date().toISOString().slice(0, 10);
                downloadRawFile(`plis-pelanggan-${today}.csv`, exportCustomersToCSV(customers, transactions), 'text/csv;charset=utf-8;');
              }}
              className="w-full flex items-center justify-center gap-1.5 py-1.5 text-xs font-semibold bg-white hover:bg-sky-50 text-sky-700 border border-sky-200 rounded-lg shadow-2xs transition-colors cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Unduh CSV (Excel)</span>
            </button>
          </div>

          {/* Card 3: CSV Pengeluaran */}
          <div className="p-3.5 bg-slate-50 hover:bg-slate-100/80 rounded-xl border border-slate-200 transition-colors flex flex-col justify-between space-y-3">
            <div>
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                  <FileSpreadsheet className="w-4 h-4 text-amber-600" />
                  Buku Biaya/Beban
                </span>
                <span className="text-[10px] bg-white px-1.5 py-0.5 rounded border border-slate-200 text-slate-600 font-mono">
                  {expenses.length} bukti
                </span>
              </div>
              <p className="text-[11px] text-slate-500 mt-1">
                Pengeluaran operasional (deterjen, listrik, gaji, perawatan) beserta nomor bukti.
              </p>
            </div>
            <button
              type="button"
              onClick={() => {
                const today = new Date().toISOString().slice(0, 10);
                downloadRawFile(`plis-pengeluaran-${today}.csv`, exportExpensesToCSV(expenses), 'text/csv;charset=utf-8;');
              }}
              className="w-full flex items-center justify-center gap-1.5 py-1.5 text-xs font-semibold bg-white hover:bg-amber-50 text-amber-800 border border-amber-200 rounded-lg shadow-2xs transition-colors cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Unduh CSV (Excel)</span>
            </button>
          </div>

          {/* Card 4: JSON Backup Utuh */}
          <div className="p-3.5 bg-slate-50 hover:bg-slate-100/80 rounded-xl border border-slate-200 transition-colors flex flex-col justify-between space-y-3">
            <div>
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                  <Code2 className="w-4 h-4 text-indigo-600" />
                  Backup Utuh JSON
                </span>
                <span className="text-[10px] bg-indigo-50 text-indigo-700 px-1.5 py-0.5 rounded border border-indigo-200 font-semibold">
                  Semua Data
                </span>
              </div>
              <p className="text-[11px] text-slate-500 mt-1">
                Cadangan lengkap semua tabel termasuk pengaturan untuk dipulihkan kembali.
              </p>
            </div>
            <button
              type="button"
              onClick={handleDownloadBackup}
              className="w-full flex items-center justify-center gap-1.5 py-1.5 text-xs font-semibold bg-indigo-50 hover:bg-indigo-100 text-indigo-800 border border-indigo-200 rounded-lg shadow-2xs transition-colors cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Unduh File JSON</span>
            </button>
          </div>
        </div>

        {/* Live Raw Data Inspector */}
        <div className="p-4 rounded-xl bg-slate-900 text-slate-100 space-y-3 shadow-inner">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-2">
            <div className="flex items-center gap-2">
              <Eye className="w-4 h-4 text-emerald-400" />
              <span className="text-xs font-bold tracking-wider uppercase text-slate-200">
                Pratinjau Data Mentah Langsung (Live Inspector)
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleCopyContent}
                className="flex items-center gap-1 px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] font-semibold border border-slate-700 transition-colors cursor-pointer"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-400">Tersalin ke Clipboard!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5 text-slate-400" />
                    <span>Salin Data Ini</span>
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={handleDownloadActiveTab}
                className="flex items-center gap-1 px-2.5 py-1 rounded bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-semibold transition-colors cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Unduh</span>
              </button>
            </div>
          </div>

          {/* Inspector Tabs */}
          <div className="flex flex-wrap items-center gap-1 bg-slate-800/80 p-1 rounded-lg text-xs">
            <button
              type="button"
              onClick={() => setInspectorTab('json')}
              className={`px-2.5 py-1 rounded font-medium cursor-pointer transition-colors ${
                inspectorTab === 'json' ? 'bg-slate-950 text-emerald-400 font-bold shadow-xs' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              JSON Lengkap
            </button>
            <button
              type="button"
              onClick={() => setInspectorTab('csv_tx')}
              className={`px-2.5 py-1 rounded font-medium cursor-pointer transition-colors ${
                inspectorTab === 'csv_tx' ? 'bg-slate-950 text-emerald-400 font-bold shadow-xs' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              CSV Transaksi
            </button>
            <button
              type="button"
              onClick={() => setInspectorTab('csv_cust')}
              className={`px-2.5 py-1 rounded font-medium cursor-pointer transition-colors ${
                inspectorTab === 'csv_cust' ? 'bg-slate-950 text-emerald-400 font-bold shadow-xs' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              CSV Pelanggan
            </button>
            <button
              type="button"
              onClick={() => setInspectorTab('csv_exp')}
              className={`px-2.5 py-1 rounded font-medium cursor-pointer transition-colors ${
                inspectorTab === 'csv_exp' ? 'bg-slate-950 text-emerald-400 font-bold shadow-xs' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              CSV Pengeluaran
            </button>
            <button
              type="button"
              onClick={() => setInspectorTab('csv_pay')}
              className={`px-2.5 py-1 rounded font-medium cursor-pointer transition-colors ${
                inspectorTab === 'csv_pay' ? 'bg-slate-950 text-emerald-400 font-bold shadow-xs' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              CSV Pembayaran
            </button>
          </div>

          {/* Monospace Code Preview Box */}
          <div className="relative">
            <pre className="max-h-56 overflow-auto bg-slate-950 p-3 rounded-lg text-[11px] font-mono text-emerald-300/90 leading-relaxed border border-slate-800 selection:bg-emerald-900 selection:text-white">
              {getRawContent()}
            </pre>
          </div>
        </div>

        {/* Restore & Reset actions */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-100">
          <label className="flex items-center gap-2 px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg border border-slate-300 transition-colors cursor-pointer">
            <Upload className="w-3.5 h-3.5" />
            <span>Pulihkan / Timpa dari Berkas Cadangan JSON</span>
            <input
              type="file"
              accept=".json"
              onChange={handleImportFile}
              className="hidden"
            />
          </label>

          <button
            type="button"
            onClick={handleReset}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-rose-600 hover:text-rose-800 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer ml-auto"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Kembalikan ke Dataset Contoh Bawaan</span>
          </button>
        </div>
      </div>

      {/* Section 4: Cara Memasang & Membawa Aplikasi Ini */}
      <div className="bg-gradient-to-br from-slate-900 to-slate-800 text-white p-5 rounded-2xl shadow-sm border border-slate-700 space-y-4">
        <div className="flex items-center gap-2 pb-2 border-b border-slate-700">
          <Store className="w-4 h-4 text-emerald-400" />
          <h2 className="text-sm font-bold uppercase tracking-wider text-white">
            4. Cara Mengambil & Memakai Aplikasi Ini
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
          <div className="bg-slate-800/80 p-3.5 rounded-xl border border-slate-700/80 space-y-2">
            <span className="font-bold text-emerald-400 block text-xs">
              1. Pasang Langsung ke HP (PWA)
            </span>
            <p className="text-slate-300 leading-relaxed text-[11px]">
              Klik tombol <strong>"Pasang ke HP"</strong> di bilah atas saat membuka tautan di Chrome (Android) atau pilih <em>"Tambahkan ke Layar Utama"</em> di Safari (iPhone). Ikon aplikasi PLIS akan langsung terpasang di HP Anda.
            </p>
          </div>

          <div className="bg-slate-800/80 p-3.5 rounded-xl border border-slate-700/80 space-y-2">
            <span className="font-bold text-emerald-400 block text-xs">
              2. Buka Tautan Web di Mana Saja
            </span>
            <p className="text-slate-300 leading-relaxed text-[11px]">
              Tautan aplikasi Anda (Shared URL) dapat dibuka di HP, tablet kasir, atau laptop kasir secara bersamaan tanpa perlu instalasi rumit.
            </p>
          </div>

          <div className="bg-slate-800/80 p-3.5 rounded-xl border border-slate-700/80 space-y-2">
            <span className="font-bold text-emerald-400 block text-xs">
              3. Unduh Kode Sumber (Source Code)
            </span>
            <p className="text-slate-300 leading-relaxed text-[11px]">
              Anda dapat mengunduh seluruh berkas kode proyek ini kapan saja melalui menu pojok kanan atas AI Studio: <strong>Export to GitHub</strong> atau <strong>Download ZIP</strong>.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
