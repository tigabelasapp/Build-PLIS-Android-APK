import type { ITEM_STATUSES, PAYMENT_METHODS, PAYMENT_STATUSES, SERVICE_UNITS, THERMAL_WIDTHS } from '../shared/constants/domain';

export type ItemStatus = (typeof ITEM_STATUSES)[number];

export type PaymentStatus = (typeof PAYMENT_STATUSES)[number];

export type PaymentMethod = (typeof PAYMENT_METHODS)[number];

export type ServiceCategory = 'Kiloan' | 'Satuan' | 'Express' | 'Sepatu & Tas' | 'Dry Clean' | 'Karpet & Gorden' | 'Lainnya';

export type ServiceUnit = (typeof SERVICE_UNITS)[number];

export interface Customer {
  id: string;
  name: string;
  phone: string;
  address: string;
  notes?: string;
  createdAt: string;
}

export interface ServiceMaster {
  id: string;
  name: string;
  category: ServiceCategory;
  unit: ServiceUnit;
  pricePerUnit: number;
  defaultDurationHours: number;
  description?: string;
}

export interface OrderItem {
  id: string;
  serviceId: string;
  serviceName: string;
  category: ServiceCategory;
  quantity: number;
  unit: ServiceUnit;
  pricePerUnit: number;
  subtotal: number;
  estimatedCompletionDate: string; // ISO string
  status: ItemStatus;
  notes?: string;
  completedAt?: string;
  deliveredAt?: string;
}

export interface Transaction {
  id: string; // e.g. PLIS-261015-001 (Unique, permanent)
  customerId: string;
  customerName: string;
  customerPhone: string;
  customerAddress?: string;
  createdAt: string; // ISO string
  items: OrderItem[];
  totalAmount: number;
  discount: number;
  grandTotal: number;
  paidAmount: number;
  paymentStatus: PaymentStatus;
  notes?: string;
}

export interface PaymentRecord {
  id: string;
  transactionId: string;
  amount: number;
  method: PaymentMethod;
  date: string; // ISO string
  notes?: string;
  customerName?: string;
}

export type ExpenseCategory = 
  | 'Bahan Baku (Sabun/Parfum)' 
  | 'Operasional & Listrik' 
  | 'Gaji Karyawan' 
  | 'Perawatan & Servis Mesin' 
  | 'Sewa Tempat' 
  | 'Transport & Kurir' 
  | 'Lain-lain';

export interface Expense {
  id: string; // e.g. EXP-261015-001 (Unique, permanent)
  date: string; // ISO string
  category: ExpenseCategory;
  description: string;
  amount: number;
  recipient: string;
  notes?: string;
}

export interface AppSettings {
  storeName: string;
  storeTagline: string;
  storeAddress: string;
  storePhone: string;
  storeInstagram?: string;
  receiptFooter: string;
  currencySymbol: string;
  thermalWidth: (typeof THERMAL_WIDTHS)[number];
  idPrefix: string;
  expensePrefix: string;
}

export type MainTab = 
  | 'dashboard' 
  | 'transaksi' 
  | 'pelanggan' 
  | 'proses_laundry' 
  | 'pembayaran' 
  | 'pengeluaran' 
  | 'laporan' 
  | 'master_data' 
  | 'pengaturan';

export type ViewportMode = 'mobile' | 'desktop';

