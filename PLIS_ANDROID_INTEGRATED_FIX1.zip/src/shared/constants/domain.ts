/** Nilai domain terpusat. Pertahankan nilai tersimpan agar data lama tetap kompatibel. */
export const ITEM_STATUSES = [
  'menunggu',
  'proses',
  'selesai',
  'siap_diambil',
  'diserahkan',
] as const;

export const PAYMENT_STATUSES = ['belum_bayar', 'sebagian', 'lunas'] as const;
export const PAYMENT_METHODS = ['tunai', 'transfer', 'qris'] as const;
export const SERVICE_UNITS = ['kg', 'pcs', 'pasang', 'set', 'm²', 'meter'] as const;
export const THERMAL_WIDTHS = ['58mm', '80mm'] as const;
