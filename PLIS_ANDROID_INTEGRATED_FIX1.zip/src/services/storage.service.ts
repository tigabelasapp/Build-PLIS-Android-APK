/** Lapisan service untuk penyimpanan. Dapat diarahkan ke repository lain kelak. */
import { readLocalValue, writeLocalValue } from '../infrastructure/storage/local-storage.repository';

export function loadStoredValue<T>(key: string, fallback: T): T {
  return readLocalValue(key, fallback);
}

export function saveStoredValue<T>(key: string, value: T): boolean {
  return writeLocalValue(key, value);
}
