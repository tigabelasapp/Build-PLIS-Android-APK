import { ItemStatus, PaymentStatus, Transaction, AppSettings } from '../types';

export function formatRupiah(amount: number): string {
  return new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount);
}

export function formatSimpleDate(isoString: string): string {
  if (!isoString) return '-';
  try {
    const d = new Date(isoString);
    return new Intl.DateTimeFormat('id-ID', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
    }).format(d);
  } catch {
    return isoString;
  }
}

export function formatDateTime(isoString: string): string {
  if (!isoString) return '-';
  try {
    const d = new Date(isoString);
    return new Intl.DateTimeFormat('id-ID', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    }).format(d);
  } catch {
    return isoString;
  }
}

export function getItemStatusLabel(status: ItemStatus): string {
  switch (status) {
    case 'menunggu':
      return 'Menunggu Pengerjaan';
    case 'proses':
      return 'Sedang Dikerjakan';
    case 'selesai':
      return 'Selesai Dikerjakan';
    case 'siap_diambil':
      return 'Siap Diambil';
    case 'diserahkan':
      return 'Diserahkan';
    default:
      return status;
  }
}

export function getItemStatusBadgeClasses(status: ItemStatus): string {
  switch (status) {
    case 'menunggu':
      return 'bg-amber-50 text-amber-800 border border-amber-200/80';
    case 'proses':
      return 'bg-sky-50 text-sky-800 border border-sky-200/80';
    case 'selesai':
      return 'bg-indigo-50 text-indigo-800 border border-indigo-200/80';
    case 'siap_diambil':
      return 'bg-emerald-50 text-emerald-800 border border-emerald-300 font-medium';
    case 'diserahkan':
      return 'bg-slate-100 text-slate-600 border border-slate-200';
    default:
      return 'bg-slate-100 text-slate-700';
  }
}

export function getPaymentStatusLabel(status: PaymentStatus): string {
  switch (status) {
    case 'lunas':
      return 'Lunas';
    case 'sebagian':
      return 'Sebagian (DP)';
    case 'belum_bayar':
      return 'Belum Dibayar';
    default:
      return status;
  }
}

export function getPaymentStatusBadgeClasses(status: PaymentStatus): string {
  switch (status) {
    case 'lunas':
      return 'bg-emerald-50 text-emerald-700 border border-emerald-200';
    case 'sebagian':
      return 'bg-amber-50 text-amber-700 border border-amber-200';
    case 'belum_bayar':
      return 'bg-rose-50 text-rose-700 border border-rose-200';
    default:
      return 'bg-slate-100 text-slate-700';
  }
}

/**
 * Calculates the overall aggregate status of a transaction based on its individual items
 */
export function getTransactionDerivedStatus(tx: Transaction): {
  label: string;
  badgeClass: string;
  isAllDelivered: boolean;
  readyCount: number;
  totalCount: number;
} {
  const items = tx.items || [];
  if (items.length === 0) {
    return {
      label: 'Tanpa Item',
      badgeClass: 'bg-slate-100 text-slate-500',
      isAllDelivered: false,
      readyCount: 0,
      totalCount: 0,
    };
  }

  const allDelivered = items.every((i) => i.status === 'diserahkan');
  if (allDelivered) {
    return {
      label: 'Selesai (Semua Diserahkan)',
      badgeClass: 'bg-slate-100 text-slate-600 border border-slate-200',
      isAllDelivered: true,
      readyCount: items.length,
      totalCount: items.length,
    };
  }

  const readyOrDelivered = items.filter((i) => i.status === 'siap_diambil' || i.status === 'diserahkan');
  const readyOnly = items.filter((i) => i.status === 'siap_diambil');

  if (readyOnly.length > 0) {
    return {
      label: `${readyOnly.length} Item Siap Diambil`,
      badgeClass: 'bg-emerald-50 text-emerald-700 border border-emerald-200',
      isAllDelivered: false,
      readyCount: readyOrDelivered.length,
      totalCount: items.length,
    };
  }

  const inProgress = items.filter((i) => i.status === 'proses');
  if (inProgress.length > 0) {
    return {
      label: 'Sedang Dikerjakan',
      badgeClass: 'bg-sky-50 text-sky-700 border border-sky-200',
      isAllDelivered: false,
      readyCount: readyOrDelivered.length,
      totalCount: items.length,
    };
  }

  return {
    label: 'Menunggu Antrean',
    badgeClass: 'bg-amber-50 text-amber-700 border border-amber-200',
    isAllDelivered: false,
    readyCount: 0,
    totalCount: items.length,
  };
}

export function generateWhatsAppMessage(tx: Transaction, settings: AppSettings): string {
  const remaining = tx.grandTotal - tx.paidAmount;
  const itemsList = tx.items
    .map(
      (item, idx) =>
        `${idx + 1}. *${item.serviceName}* (${item.quantity} ${item.unit})\n` +
        `   Status: _${getItemStatusLabel(item.status)}_\n` +
        `   Estimasi: ${formatDateTime(item.estimatedCompletionDate)}`
    )
    .join('\n\n');

  return encodeURIComponent(
    `Halo kak *${tx.customerName}*,\n` +
    `Terima kasih telah mempercayakan cucian Anda di *${settings.storeName}* ✨\n\n` +
    `📋 *RINCIAN NOTA: ${tx.id}*\n` +
    `Tanggal: ${formatDateTime(tx.createdAt)}\n\n` +
    `🧺 *STATUS ITEM CUCIAN:*\n` +
    `${itemsList}\n\n` +
    `💳 *INFORMASI PEMBAYARAN:*\n` +
    `Total Biaya: ${formatRupiah(tx.grandTotal)}\n` +
    `Terbayar: ${formatRupiah(tx.paidAmount)}\n` +
    `Sisa Tagihan: *${formatRupiah(remaining)}* (${getPaymentStatusLabel(tx.paymentStatus)})\n\n` +
    `${settings.receiptFooter || 'Cucian bersih, rapi, dan higienis.'}\n` +
    `Hubungi kami: ${settings.storePhone}`
  );
}
