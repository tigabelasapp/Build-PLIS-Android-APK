import { Transaction, Customer, Expense, PaymentRecord } from '../types';

function escapeCSV(val: any): string {
  if (val === null || val === undefined) return '""';
  const str = String(val).replace(/"/g, '""');
  return `"${str}"`;
}

export function exportTransactionsToCSV(transactions: Transaction[]): string {
  const headers = [
    'ID Nota',
    'Tanggal Nota',
    'Nama Pelanggan',
    'No Telepon',
    'Alamat Pelanggan',
    'Jumlah Item',
    'Rincian Layanan',
    'Total Tagihan (Rp)',
    'Sudah Dibayar (Rp)',
    'Sisa Tagihan (Rp)',
    'Status Pembayaran',
    'Status Pengerjaan Item',
  ];

  const rows = transactions.map((t) => {
    const serviceList = t.items.map((i) => `${i.serviceName} (${i.quantity} ${i.unit}) [${i.status}]`).join('; ');
    const statuses = t.items.map((i) => i.status).join(', ');
    const remaining = Math.max(0, t.grandTotal - t.paidAmount);

    return [
      escapeCSV(t.id),
      escapeCSV(t.createdAt),
      escapeCSV(t.customerName),
      escapeCSV(t.customerPhone),
      escapeCSV(t.customerAddress || '-'),
      escapeCSV(t.items.length),
      escapeCSV(serviceList),
      escapeCSV(t.grandTotal),
      escapeCSV(t.paidAmount),
      escapeCSV(remaining),
      escapeCSV(t.paymentStatus),
      escapeCSV(statuses),
    ].join(',');
  });

  return [headers.join(','), ...rows].join('\r\n');
}

export function exportCustomersToCSV(customers: Customer[], transactions: Transaction[] = []): string {
  const headers = [
    'ID Pelanggan',
    'Nama Lengkap',
    'No WhatsApp / Telepon',
    'Alamat',
    'Catatan Khusus',
    'Total Nota',
    'Total Belanja (Rp)',
    'Terdaftar Sejak',
  ];

  const rows = customers.map((c) => {
    const custTx = transactions.filter((t) => t.customerId === c.id);
    const totalOrders = custTx.length;
    const totalSpent = custTx.reduce((sum, t) => sum + t.grandTotal, 0);

    return [
      escapeCSV(c.id),
      escapeCSV(c.name),
      escapeCSV(c.phone),
      escapeCSV(c.address || '-'),
      escapeCSV(c.notes || '-'),
      escapeCSV(totalOrders),
      escapeCSV(totalSpent),
      escapeCSV(c.createdAt),
    ].join(',');
  });

  return [headers.join(','), ...rows].join('\r\n');
}

export function exportExpensesToCSV(expenses: Expense[]): string {
  const headers = [
    'ID Pengeluaran',
    'Tanggal',
    'Kategori Biaya',
    'Keterangan / Keperluan',
    'Nominal (Rp)',
    'Penerima / Vendor',
    'Catatan Tambahan',
  ];

  const rows = expenses.map((e) => {
    return [
      escapeCSV(e.id),
      escapeCSV(e.date),
      escapeCSV(e.category),
      escapeCSV(e.description),
      escapeCSV(e.amount),
      escapeCSV(e.recipient || '-'),
      escapeCSV(e.notes || '-'),
    ].join(',');
  });

  return [headers.join(','), ...rows].join('\r\n');
}

export function exportPaymentsToCSV(payments: PaymentRecord[]): string {
  const headers = [
    'ID Pembayaran',
    'ID Nota Transaksi',
    'Tanggal & Waktu',
    'Nama Pelanggan',
    'Nominal Masuk (Rp)',
    'Metode Pembayaran',
    'Catatan Pembayaran',
  ];

  const rows = payments.map((p) => {
    return [
      escapeCSV(p.id),
      escapeCSV(p.transactionId),
      escapeCSV(p.date),
      escapeCSV(p.customerName || '-'),
      escapeCSV(p.amount),
      escapeCSV(p.method),
      escapeCSV(p.notes || '-'),
    ].join(',');
  });

  return [headers.join(','), ...rows].join('\r\n');
}

export function downloadRawFile(filename: string, content: string, mimeType: string) {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.setAttribute('download', filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
